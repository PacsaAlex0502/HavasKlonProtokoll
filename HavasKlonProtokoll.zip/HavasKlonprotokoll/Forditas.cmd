@echo off
setlocal
cd /d "%~dp0"
set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" (
  echo Nem talalhato a .NET Framework C# fordito. Hasznald a Visual Studio solutiont.
  pause
  exit /b 1
)
if not exist "bin\Release" mkdir "bin\Release"
"%HAVAS_CSC%" /nologo /langversion:5 /optimize+ /target:winexe /out:bin\Release\HavasKlonprotokoll.exe /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll /resource:Assets\havas-attila.jpg,HavasKlonprotokoll.Assets.havas-attila.jpg /resource:Assets\havas.ico,HavasKlonprotokoll.Assets.havas.ico /win32icon:Assets\havas.ico /win32manifest:app.manifest Program.cs GameForm.cs Rendering.cs Model.cs Simulation.cs Audio.cs Profile.cs Properties\AssemblyInfo.cs
if errorlevel 1 (
  echo A forditas sikertelen.
  pause
  exit /b 1
)
copy /y App.config bin\Release\HavasKlonprotokoll.exe.config >nul
echo Kesz: bin\Release\HavasKlonprotokoll.exe
pause
