using System;
using System.Collections.Generic;

namespace HavasKlonprotokoll
{
    // All gameplay is independent of Forms. A fixed 120 Hz step drives this model.
    public class World
    {
        public const float Left = 42, Right = 1238, Top = 140, Bottom = 706;
        public const int LastWave = 15;
        public static readonly V2[] Pillars = { new V2(380, 330), new V2(900, 330), new V2(380, 530), new V2(900, 530) };
        public static readonly Weapon[] Weapons = {
            new Weapon("HA–01 KARABÉLY", "AUTOMATA / PONTOS", 30, 1, 22, .115f, 1.25f, 980, .025f),
            new Weapon("HAVAS SÖRÉTES", "7 LÖVEDÉK / KÖZELHARC", 7, 7, 11, .63f, 1.7f, 820, .26f),
            new Weapon("PRÍM SÍNPUSKA", "ÁTÜTŐ / NAGY SEBZÉS", 5, 1, 115, .83f, 1.9f, 1650, 0)
        };
        public readonly List<Enemy> Enemies = new List<Enemy>();
        public readonly List<Bullet> Bullets = new List<Bullet>();
        public readonly List<Particle> Particles = new List<Particle>();
        public readonly List<FloatingText> Texts = new List<FloatingText>();
        public readonly List<Pickup> Pickups = new List<Pickup>();
        public readonly List<Hazard> Hazards = new List<Hazard>();
        public readonly List<Upgrade> Choices = new List<Upgrade>();
        public readonly Dictionary<string, int> Upgrades = new Dictionary<string, int>();
        public readonly int[] Ammo = { 30, 7, 5 };
        public V2 Player = new V2(640, 440), Aim = new V2(900, 440), DashDirection;
        public float Hp = 125, MaxHp = 125, Time, WaveTime, DamageScale = 1, FireScale = 1, MoveScale = 1;
        public float DashCooldown, DashTime, Invulnerable, FireTimer, ReloadTimer, ReloadTotal, Charge = 30;
        public float Shake, HurtFlash, NovaFlash, BannerTimer, ComboTime, DamageTaken, DistanceTravelled;
        public int WeaponIndex, Wave, Score, Kills, Combo, BestCombo, SpawnRemaining, TotalWaveEnemies, ShotsFired;
        public bool Hardcore, Dead, Won, AwaitingUpgrade, BossEncounter;
        public string Banner = "", SubBanner = "";
        public Action<EffectKind> Sound;
        private readonly Random rng;
        private float spawnClock, clearClock, regenClock;
        private int nextId, reloadWeapon;
        public World(bool hardcore, int seed = 0)
        { Hardcore = hardcore; rng = seed == 0 ? new Random() : new Random(seed); StartWave(); }
        public int Level(string id) { int n; return Upgrades.TryGetValue(id, out n) ? n : 0; }
        public int Magazine(int i) { return Weapons[i].Magazine + Level("mag") * (i == 0 ? 6 : 1); }
        public float DashDuration { get { return .18f; } }
        public float DashMax { get { return Math.Max(.65f, 1.65f - Level("dash") * .2f); } }
        public float ReloadProgress { get { return ReloadTimer > 0 ? 1 - ReloadTimer / ReloadTotal : 0; } }
        private void Sfx(EffectKind k) { if (Sound != null) Sound(k); }
        private float Rand(float lo, float hi) { return lo + (float)rng.NextDouble() * (hi - lo); }
        private static float Clamp(float v, float lo, float hi) { return Math.Max(lo, Math.Min(hi, v)); }

        public void StartWave()
        {
            Wave++; WaveTime = 0; AwaitingUpgrade = false; clearClock = 0; spawnClock = 1.65f;
            Bullets.Clear(); Hazards.Clear(); BossEncounter = Wave % 5 == 0;
            SpawnRemaining = BossEncounter ? 5 + Wave : 8 + Wave * 3;
            TotalWaveEnemies = SpawnRemaining + (BossEncounter ? 1 : 0);
            Banner = BossEncounter ? "HAVAS PRÍM ÉBRED" : Wave.ToString("00") + " / KLÓNHULLÁM";
            SubBanner = BossEncounter ? "A MÁSOLAT AZ EREDETI HELYÉRE TÖR." : "CSAK EGY IGAZI HAVAS ATTILA MARADHAT.";
            BannerTimer = 3.3f;
            if (BossEncounter) Spawn(EnemyKind.Prime, new V2(640, 218));
            Sfx(BossEncounter ? EffectKind.Boss : EffectKind.Wave);
        }
        public void SwitchWeapon(int index)
        { if (index < 0 || index > 2 || index == WeaponIndex) return; WeaponIndex = index; ReloadTimer = 0; FireTimer = Math.Max(FireTimer, .12f); }
        public void BeginReload()
        {
            if (ReloadTimer > 0 || Ammo[WeaponIndex] >= Magazine(WeaponIndex)) return;
            reloadWeapon = WeaponIndex;
            ReloadTotal = Weapons[WeaponIndex].Reload * (float)Math.Pow(.85, Level("reload"));
            ReloadTimer = ReloadTotal; Sfx(EffectKind.Reload);
        }
        public void Update(float dt, InputFrame input)
        {
            if (Dead || Won || AwaitingUpgrade) return;
            Time += dt; WaveTime += dt; Aim = input.Aim;
            FireTimer = Math.Max(0, FireTimer - dt); DashCooldown = Math.Max(0, DashCooldown - dt);
            Invulnerable = Math.Max(0, Invulnerable - dt); DashTime = Math.Max(0, DashTime - dt);
            HurtFlash = Math.Max(0, HurtFlash - dt * 2); NovaFlash = Math.Max(0, NovaFlash - dt * 1.8f);
            Shake = Math.Max(0, Shake - dt * 26); BannerTimer = Math.Max(0, BannerTimer - dt);
            ComboTime = Math.Max(0, ComboTime - dt); if (ComboTime <= 0) Combo = 0;
            if (ReloadTimer > 0) { ReloadTimer -= dt; if (ReloadTimer <= 0) { ReloadTimer = 0; Ammo[reloadWeapon] = Magazine(reloadWeapon); } }
            if (input.Reload) BeginReload();
            if (input.Dash && DashCooldown <= 0)
            {
                DashDirection = input.Move.Length > .05f ? input.Move.Unit : (Aim - Player).Unit;
                DashTime = DashDuration; DashCooldown = DashMax; Invulnerable = Math.Max(Invulnerable, .27f);
                Burst(Player, 17, 0, 140); Sfx(EffectKind.Dash);
            }
            V2 before = Player;
            V2 motion = DashTime > 0 ? DashDirection * 1100 : input.Move * (246 * MoveScale);
            // Substeps prevent dashing through pillars and bounds.
            int steps = DashTime > 0 ? 4 : 1;
            for (int s = 0; s < steps; s++) Player = Resolve(Player + motion * (dt / steps), 20);
            DistanceTravelled += V2.Distance(before, Player);
            if (DashTime > 0) AddParticle(Player, new V2(0, 0), .22f, 14, 0);
            if (input.Nova && Charge >= 100) UseNova();
            if (input.Shoot && ReloadTimer <= 0 && FireTimer <= 0) Fire();
            if (Level("regen") > 0) { regenClock += dt; if (regenClock >= 4) { Hp = Math.Min(MaxHp, Hp + 2 * Level("regen")); regenClock = 0; } }
            UpdateSpawns(dt);
            UpdateEnemies(dt);
            UpdateBullets(dt);
            UpdateHazards(dt);
            UpdatePickups(dt);
            UpdateEffects(dt);
            Enemies.RemoveAll(e => e.Dead);
            if (Hp <= 0) { Hp = 0; Dead = true; Sfx(EffectKind.Boss); return; }
            if (SpawnRemaining == 0 && Enemies.Count == 0)
            {
                clearClock += dt;
                if (clearClock > 1.25f)
                {
                    Bullets.Clear(); Hazards.Clear();
                    // Every cleared wave collects all remaining drops before the choice screen.
                    foreach (Pickup p in Pickups) Collect(p); Pickups.Clear();
                    Score += Wave * 120; Hp = Math.Min(MaxHp, Hp + (Hardcore ? 8 : 17));
                    for (int i = 0; i < 3; i++) Ammo[i] = Magazine(i);
                    ReloadTimer = 0;
                    if (Wave >= LastWave) { Won = true; Score += 5000; }
                    else { AwaitingUpgrade = true; RollUpgrades(); Sfx(EffectKind.Upgrade); }
                }
            }
        }
        private void Fire()
        {
            if (Ammo[WeaponIndex] <= 0) { BeginReload(); return; }
            Weapon w = Weapons[WeaponIndex]; Ammo[WeaponIndex]--; ShotsFired++;
            FireTimer = w.Interval / FireScale;
            float a = (Aim - Player).Angle;
            for (int i = 0; i < w.Pellets; i++)
            {
                float spread = w.Pellets > 1 ? (i - 3) / 3f * w.Spread + Rand(-.025f, .025f) : Rand(-w.Spread, w.Spread);
                V2 dir = V2.FromAngle(a + spread);
                Bullets.Add(new Bullet { Pos = Player + dir * 28, Last = Player, Velocity = dir * w.Speed,
                    Damage = w.Damage * DamageScale, Life = WeaponIndex == 1 ? .48f : 1.25f,
                    Radius = WeaponIndex == 2 ? 4 : 3, Rail = WeaponIndex == 2, Pierce = WeaponIndex == 2 ? 5 : 1 });
            }
            Burst(Player + V2.FromAngle(a) * 31, 5, 3, 90); Shake = Math.Max(Shake, WeaponIndex == 1 ? 3.5f : 1.7f);
            Sfx(EffectKind.Shot);
        }
        private void UseNova()
        {
            Charge = 0; NovaFlash = 1; Shake = 12; Invulnerable = Math.Max(Invulnerable, .7f);
            float radius = 270 + Level("nova") * 35;
            int targetCount = Enemies.Count;
            for (int i = 0; i < targetCount; i++)
            { Enemy e = Enemies[i]; if (!e.Dead && V2.Distance(e.Pos, Player) < radius + e.Radius)
                DamageEnemy(e, (185 + Level("nova") * 70) * DamageScale, (e.Pos - Player).Unit * 360); }
            Bullets.RemoveAll(b => b.Hostile && V2.Distance(b.Pos, Player) < radius);
            for (int i = 0; i < 85; i++) { V2 d = V2.FromAngle(Rand(0, 6.284f)); AddParticle(Player + d * 15, d * Rand(140, 700), .7f, Rand(2, 6), 0); }
            Float(Player + new V2(0, -40), "HAVAS-PULZUS", 0); Sfx(EffectKind.Nova);
        }
        private void UpdateSpawns(float dt)
        {
            if (SpawnRemaining <= 0) return;
            spawnClock -= dt;
            if (spawnClock > 0 || Enemies.Count >= 38) return;
            spawnClock = Math.Max(.22f, .84f - Wave * .035f) * (Hardcore ? .85f : 1);
            int roll = rng.Next(100); EnemyKind kind = EnemyKind.Stalker;
            if (Wave >= 2 && roll < 28) kind = EnemyKind.Runner;
            if (Wave >= 3 && roll >= 28 && roll < 49) kind = EnemyKind.Gunner;
            if (Wave >= 4 && roll >= 49 && roll < 62) kind = EnemyKind.Tank;
            if (Wave >= 6 && roll >= 62 && roll < 77) kind = EnemyKind.Splitter;
            V2 p; int tries = 0;
            do { int side = rng.Next(4); p = side == 0 ? new V2(Left + 22, Rand(Top + 24, Bottom - 24)) : side == 1 ? new V2(Right - 22, Rand(Top + 24, Bottom - 24)) : side == 2 ? new V2(Rand(Left + 24, Right - 24), Top + 22) : new V2(Rand(Left + 24, Right - 24), Bottom - 22); tries++; }
            while (V2.Distance(p, Player) < 260 && tries < 12);
            Spawn(kind, p); SpawnRemaining--;
        }
        public Enemy Spawn(EnemyKind kind, V2 pos)
        {
            float scale = 1 + (Wave - 1) * .075f;
            Enemy e = new Enemy { Id = ++nextId, Kind = kind, Pos = pos, AttackTimer = Rand(1, 2), Windup = 0 };
            switch (kind)
            {
                case EnemyKind.Runner: e.MaxHp = 32; e.Speed = 152; e.Radius = 17; break;
                case EnemyKind.Gunner: e.MaxHp = 65; e.Speed = 65; e.Radius = 22; break;
                case EnemyKind.Tank: e.MaxHp = 240; e.Speed = 48; e.Radius = 34; break;
                case EnemyKind.Splitter: e.MaxHp = 100; e.Speed = 86; e.Radius = 25; break;
                case EnemyKind.Prime: e.MaxHp = 1700 + Wave * 120; e.Speed = 51; e.Radius = 58; break;
                default: e.MaxHp = 53; e.Speed = 92; e.Radius = 22; break;
            }
            e.MaxHp *= e.Boss ? (Hardcore ? 1.18f : 1) : scale * (Hardcore ? 1.12f : 1);
            e.Hp = e.MaxHp; e.Speed *= (1 + Wave * .012f) * (Hardcore ? 1.12f : 1);
            Enemies.Add(e); Burst(pos, 10, EnemyColor(kind), 80); return e;
        }
        private void UpdateEnemies(float dt)
        {
            // Snapshot count: splitter children begin AI on the next step.
            int count = Enemies.Count;
            for (int i = 0; i < count; i++)
            {
                Enemy e = Enemies[i]; if (e.Dead) continue;
                e.Age += dt; e.Flash = Math.Max(0, e.Flash - dt * 6); e.AttackTimer -= dt;
                V2 toPlayer = Player - e.Pos; float distance = toPlayer.Length; V2 dir = toPlayer.Unit;
                float speed = e.Speed;
                if (e.Kind == EnemyKind.Gunner) { if (distance < 250) dir = dir * -1; else if (distance < 380) dir = new V2(-dir.Y, dir.X) * .5f; }
                if (e.Boss)
                {
                    e.Stage = e.Hp < e.MaxHp * .45f ? 2 : 1;
                    if (e.Windup > 0)
                    {
                        e.Windup -= dt; speed = 0;
                        if (e.Windup <= 0) { e.DashTime = .48f; e.DashDirection = (Player - e.Pos).Unit; Burst(e.Pos, 30, 1, 230); }
                    }
                    if (e.DashTime > 0) { e.DashTime -= dt; dir = e.DashDirection; speed = 650; }
                    if (e.AttackTimer <= 0 && e.Age > 1)
                    {
                        e.AttackTimer = e.Stage == 2 ? 1.5f : 2.15f;
                        int rays = e.Stage == 2 ? 18 : 12;
                        for (int b = 0; b < rays; b++) EnemyShot(e, V2.FromAngle(b * 6.283185f / rays + Time * .35f), e.Stage == 2 ? 235 : 190, 13);
                        Hazards.Add(new Hazard { Pos = Player, Radius = e.Stage == 2 ? 80 : 65, Timer = 1.05f, MaxTimer = 1.05f });
                        if (e.Stage == 2 && rng.Next(3) == 0 && e.DashTime <= 0) e.Windup = .9f;
                    }
                }
                else if (e.Kind == EnemyKind.Gunner && e.AttackTimer <= 0 && e.Age > .75f)
                { e.AttackTimer = Rand(1.7f, 2.4f) / (1 + Wave * .025f); EnemyShot(e, toPlayer.Unit, 245 + Wave * 3, 12); }
                if (e.DashTime <= 0 && e.Windup <= 0)
                {
                    // Tangential steering keeps clones from camping on the far side of a pillar.
                    foreach (V2 pillar in Pillars)
                    {
                        if (!SegmentHit(e.Pos, e.Pos + dir * 90, pillar, e.Radius + 35)) continue;
                        V2 normal = (e.Pos - pillar).Unit;
                        if (dir.X * normal.X + dir.Y * normal.Y >= .15f) continue;
                        V2 tangent = new V2(-normal.Y, normal.X);
                        float alignment = tangent.X * dir.X + tangent.Y * dir.Y;
                        if (alignment < -.01f || (Math.Abs(alignment) <= .01f && e.Id % 2 == 0)) tangent *= -1;
                        dir = (tangent + normal * .22f).Unit; break;
                    }
                }
                V2 separation = new V2(0, 0);
                for (int j = 0; j < count; j++)
                { if (i == j || Enemies[j].Dead) continue; V2 d = e.Pos - Enemies[j].Pos; float n = d.Length; float min = e.Radius + Enemies[j].Radius; if (n < min && n > .01f) separation += d / n * (min - n) * 4; }
                e.Push *= Math.Max(0, 1 - dt * 8);
                e.Pos = Resolve(e.Pos + (dir * speed + separation + e.Push) * dt, e.Radius);
                if (e.Age > .7f && V2.Distance(Player, e.Pos) < e.Radius + 17) Hurt(e.Boss ? 28 : e.Kind == EnemyKind.Tank ? 23 : 13);
            }
        }
        private void EnemyShot(Enemy e, V2 dir, float speed, float damage)
        {
            Bullets.Add(new Bullet { Pos = e.Pos + dir * (e.Radius + 7), Last = e.Pos, Velocity = dir * speed,
                Life = 5, Damage = damage, Radius = 6, Hostile = true, Pierce = 1 });
        }
        // Segment-circle collision prevents high-speed rail shots from tunnelling.
        public static bool SegmentHit(V2 a, V2 b, V2 p, float radius)
        {
            V2 d = b - a; float denom = d.X * d.X + d.Y * d.Y;
            float t = denom < .00001f ? 0 : Clamp(((p.X - a.X) * d.X + (p.Y - a.Y) * d.Y) / denom, 0, 1);
            return V2.Distance(a + d * t, p) <= radius;
        }
        private void UpdateBullets(float dt)
        {
            // Death effects may spawn enemies, but never bullets; this list is stable here.
            foreach (Bullet b in Bullets)
            {
                b.Last = b.Pos; b.Pos += b.Velocity * dt; b.Life -= dt;
                if (b.Pos.X < Left || b.Pos.X > Right || b.Pos.Y < Top || b.Pos.Y > Bottom) b.Life = 0;
                foreach (V2 pillar in Pillars) if (SegmentHit(b.Last, b.Pos, pillar, 27 + b.Radius)) { b.Life = 0; break; }
                if (b.Life <= 0) continue;
                if (b.Hostile)
                { if (SegmentHit(b.Last, b.Pos, Player, 17 + b.Radius)) { Hurt(b.Damage); b.Life = 0; } }
                else
                {
                    int count = Enemies.Count;
                    for (int i = 0; i < count; i++)
                    {
                        Enemy e = Enemies[i]; if (e.Dead || e.Age < .25f || b.Hits.Contains(e.Id)) continue;
                        if (!SegmentHit(b.Last, b.Pos, e.Pos, e.Radius + b.Radius)) continue;
                        b.Hits.Add(e.Id); bool crit = rng.NextDouble() < .08 + Level("crit") * .07;
                        float damage = b.Damage * (crit ? 2 : 1);
                        DamageEnemy(e, damage, b.Velocity.Unit * (b.Rail ? 150 : 65));
                        Float(e.Pos - new V2(0, e.Radius + 4), (crit ? "! " : "") + ((int)damage), crit ? 3 : 4);
                        b.Pierce--; if (b.Pierce <= 0) { b.Life = 0; break; }
                    }
                }
            }
            Bullets.RemoveAll(b => b.Life <= 0);
        }
        private void DamageEnemy(Enemy e, float damage, V2 push)
        {
            e.Hp -= damage; e.Push += push; e.Flash = 1;
            Burst(e.Pos, e.Boss ? 5 : 3, EnemyColor(e.Kind), 110);
            if (e.Hp > 0 || e.Dead) return;
            e.Dead = true; Kills++; Combo++; BestCombo = Math.Max(BestCombo, Combo); ComboTime = 3.5f;
            Score += (e.Boss ? 1500 : e.Kind == EnemyKind.Tank ? 70 : 30) * Math.Min(5, 1 + Combo / 8);
            Charge = Math.Min(100, Charge + (e.Boss ? 35 : 3.2f) + Level("charge") * 1.1f);
            Burst(e.Pos, e.Boss ? 65 : 17, EnemyColor(e.Kind), e.Boss ? 330 : 170); Shake = Math.Max(Shake, e.Boss ? 14 : 2);
            if (e.Kind == EnemyKind.Splitter)
            { for (int j = 0; j < 2; j++) { Enemy child = Spawn(EnemyKind.Runner, Resolve(e.Pos + new V2(j == 0 ? -22 : 22, 0), 17)); child.Hp *= .65f; child.MaxHp = child.Hp; } }
            double drop = rng.NextDouble();
            if (e.Boss || drop < .11) Pickups.Add(new Pickup { Pos = e.Pos, Kind = PickupKind.Health });
            else if (drop < .22) Pickups.Add(new Pickup { Pos = e.Pos, Kind = PickupKind.Ammo });
            else if (drop < .40) Pickups.Add(new Pickup { Pos = e.Pos, Kind = PickupKind.Energy });
            Sfx(EffectKind.Kill);
        }
        private void Hurt(float damage)
        {
            if (Invulnerable > 0 || Dead) return;
            damage *= (Hardcore ? 1.4f : 1) * (float)Math.Pow(.88, Level("armor"));
            Hp -= damage; DamageTaken += damage; Invulnerable = .72f; HurtFlash = .65f; Shake = 9; Combo = 0; ComboTime = 0;
            Burst(Player, 20, 1, 170); Sfx(EffectKind.Hurt);
        }
        private void UpdateHazards(float dt)
        {
            foreach (Hazard h in Hazards)
            {
                h.Timer -= dt;
                if (h.Timer <= 0 && !h.Fired)
                { h.Fired = true; Burst(h.Pos, 40, 1, 300); if (V2.Distance(Player, h.Pos) < h.Radius + 18) Hurt(30); }
            }
            Hazards.RemoveAll(h => h.Timer < -.35f);
        }
        private void UpdatePickups(float dt)
        {
            for (int i = Pickups.Count - 1; i >= 0; i--)
            {
                Pickup p = Pickups[i]; p.Age += dt; float distance = V2.Distance(p.Pos, Player);
                if (distance < 100 + Level("magnet") * 85) p.Pos += (Player - p.Pos).Unit * (290 * dt);
                if (distance < 27) { Collect(p); Pickups.RemoveAt(i); }
                else if (p.Age > 22) Pickups.RemoveAt(i);
            }
        }
        private void Collect(Pickup p)
        {
            if (p.Kind == PickupKind.Health) { Hp = Math.Min(MaxHp, Hp + 20); Float(p.Pos, "+20 ÉLET", 2); }
            else if (p.Kind == PickupKind.Ammo) { Ammo[WeaponIndex] = Magazine(WeaponIndex); ReloadTimer = 0; Float(p.Pos, "TÁR FELTÖLTVE", 3); }
            else { Charge = Math.Min(100, Charge + 12); Float(p.Pos, "+12 PULZUS", 0); }
            Sfx(EffectKind.Pickup);
        }
        public static V2 Resolve(V2 pos, float radius)
        {
            pos.X = Clamp(pos.X, Left + radius, Right - radius); pos.Y = Clamp(pos.Y, Top + radius, Bottom - radius);
            foreach (V2 p in Pillars)
            { V2 d = pos - p; float n = d.Length; if (n < 29 + radius) pos = p + d.Unit * (29 + radius); }
            return pos;
        }
        public static int EnemyColor(EnemyKind k)
        { return k == EnemyKind.Gunner ? 5 : k == EnemyKind.Tank ? 3 : k == EnemyKind.Splitter ? 2 : 1; }
        private void UpdateEffects(float dt)
        {
            foreach (Particle p in Particles) { p.Pos += p.Vel * dt; p.Vel *= Math.Max(0, 1 - dt * 3); p.Life -= dt; }
            Particles.RemoveAll(p => p.Life <= 0);
            foreach (FloatingText t in Texts) { t.Pos.Y -= dt * 36; t.Life -= dt; }
            Texts.RemoveAll(t => t.Life <= 0);
        }
        private void AddParticle(V2 pos, V2 vel, float life, float size, int color)
        { if (Particles.Count < 950) Particles.Add(new Particle { Pos = pos, Vel = vel, Life = life, MaxLife = life, Size = size, Color = color }); }
        private void Burst(V2 pos, int count, int color, float speed)
        { for (int i = 0; i < count; i++) AddParticle(pos, V2.FromAngle(Rand(0, 6.284f)) * Rand(speed * .2f, speed), Rand(.18f, .6f), Rand(1.5f, 4.5f), color); }
        private void Float(V2 pos, string text, int color)
        { if (Texts.Count < 80) Texts.Add(new FloatingText { Pos = pos, Text = text, Life = .9f, Color = color }); }

        private void RollUpgrades()
        {
            var pool = new List<Upgrade> {
                new Upgrade("damage", "TÚLHAJTÁS", "+18% fegyversebzés.\nMinden fegyverre érvényes.", "TŰZERŐ"),
                new Upgrade("fire", "GYORSÍTOTT REFLEX", "+13% tűzgyorsaság.\nRövidebb idő két lövés között.", "TŰZERŐ"),
                new Upgrade("health", "EREDETI DNS", "+25 maximális életerő.\nAzonnal visszatölt 35 életet.", "TÚLÉLÉS"),
                new Upgrade("speed", "KÖNNYŰ ÖLTÖNY", "+10% mozgási sebesség.\nKönnyebb kitérni a lövedékek elől.", "MOZGÁS"),
                new Upgrade("dash", "FÁZISLÉPÉS", "0,2 mp-cel rövidebb dash töltés.\nA dash közben sérthetetlen vagy.", "MOZGÁS"),
                new Upgrade("reload", "GYORS TÁRCSERE", "15%-kal gyorsabb újratöltés.\nMindhárom fegyverre érvényes.", "FEGYVER"),
                new Upgrade("mag", "BŐVÍTETT TÁR", "+6 karabély-, +1 egyéb lőszer.\nMinden tár azonnal megtelik.", "FEGYVER"),
                new Upgrade("crit", "PRECÍZIÓ", "+7% kritikus találati esély.\nA kritikus lövés duplán sebez.", "TŰZERŐ"),
                new Upgrade("armor", "KEVLÁR ÖLTÖNY", "12%-kal kevesebb kapott sebzés.\nMinden sebzésforrás ellen.", "TÚLÉLÉS"),
                new Upgrade("charge", "PULZUSMAG", "+1,1 pulzusenergia klónonként.\nAzonnal kapsz 25 energiát.", "KÉPESSÉG"),
                new Upgrade("nova", "HAVAS-REAKTOR", "+70 pulzussebzés, +35 hatótáv.\nQ: területsebzés és lövedéktörlés.", "KÉPESSÉG"),
                new Upgrade("regen", "REGENERÁCIÓ", "+2 életerő minden 4. mp-ben.\nÚjra választva tovább erősödik.", "TÚLÉLÉS"),
                new Upgrade("magnet", "MÁGNESES AURA", "+85 begyűjtési távolság.\nÉlet, lőszer és pulzus felvétele.", "TÚLÉLÉS")
            };
            pool.RemoveAll(u => Level(u.Id) >= (u.Id == "dash" ? 4 : u.Id == "crit" ? 6 : 5));
            Choices.Clear();
            for (int i = 0; i < 3 && pool.Count > 0; i++) { int j = rng.Next(pool.Count); Choices.Add(pool[j]); pool.RemoveAt(j); }
        }
        public void ChooseUpgrade(int index)
        {
            if (!AwaitingUpgrade || index < 0 || index >= Choices.Count) return;
            string id = Choices[index].Id; Upgrades[id] = Level(id) + 1;
            switch (id)
            {
                case "damage": DamageScale += .18f; break;
                case "fire": FireScale += .13f; break;
                case "health": MaxHp += 25; Hp = Math.Min(MaxHp, Hp + 35); break;
                case "speed": MoveScale += .1f; break;
                case "charge": Charge = Math.Min(100, Charge + 25); break;
            }
            for (int i = 0; i < 3; i++) Ammo[i] = Magazine(i);
            StartWave();
        }
    }
}
