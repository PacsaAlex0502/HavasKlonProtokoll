using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace HavasKlonprotokoll
{
    // Short procedural PCM effects; no external audio assets or packages required.
    public sealed class AudioEngine : IDisposable
    {
        private readonly Dictionary<EffectKind, SoundPlayer> sounds = new Dictionary<EffectKind, SoundPlayer>();
        private readonly List<MemoryStream> streams = new List<MemoryStream>();
        private readonly System.Diagnostics.Stopwatch clock = System.Diagnostics.Stopwatch.StartNew();
        private double lastSound;
        public bool Muted;
        public AudioEngine()
        {
            foreach (EffectKind kind in Enum.GetValues(typeof(EffectKind)))
            {
                try { var ms = Create(kind); streams.Add(ms); var player = new SoundPlayer(ms); player.Load(); sounds[kind] = player; }
                catch (Exception) { }
            }
        }
        private static MemoryStream Create(EffectKind kind)
        {
            int rate = 22050; double duration = kind == EffectKind.Boss ? .6 : kind == EffectKind.Nova ? .42 : kind == EffectKind.Wave ? .28 : .085;
            int samples = (int)(rate * duration); var ms = new MemoryStream();
            using (var w = new BinaryWriter(ms, System.Text.Encoding.UTF8, true))
            {
                w.Write(System.Text.Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + samples * 2);
                w.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt ")); w.Write(16); w.Write((short)1); w.Write((short)1);
                w.Write(rate); w.Write(rate * 2); w.Write((short)2); w.Write((short)16);
                w.Write(System.Text.Encoding.ASCII.GetBytes("data")); w.Write(samples * 2);
                var rng = new Random(17 + (int)kind);
                double f = kind == EffectKind.Pickup ? 900 : kind == EffectKind.Wave ? 430 : kind == EffectKind.Upgrade ? 620 : kind == EffectKind.Reload ? 260 : kind == EffectKind.Dash ? 190 : 85;
                for (int i = 0; i < samples; i++)
                {
                    double t = (double)i / rate, p = (double)i / samples;
                    double tone = Math.Sin(2 * Math.PI * (f * t + (kind == EffectKind.Pickup || kind == EffectKind.Wave ? 600 : -55) * t * t));
                    double noise = (rng.NextDouble() * 2 - 1) * (kind == EffectKind.Shot || kind == EffectKind.Hurt || kind == EffectKind.Nova ? .65 : .12);
                    double envelope = Math.Min(1, p * 35) * Math.Pow(1 - p, 2);
                    w.Write((short)((tone * .45 + noise) * envelope * 11500));
                }
            }
            ms.Position = 0; return ms;
        }
        public void Play(EffectKind kind)
        {
            if (Muted) return;
            // SoundPlayer shares an output channel; throttle small effects to avoid constant interruption.
            double now = clock.Elapsed.TotalSeconds;
            if ((kind == EffectKind.Kill || kind == EffectKind.Shot) && now - lastSound < .095) return;
            SoundPlayer p; if (sounds.TryGetValue(kind, out p)) try { p.Play(); lastSound = now; } catch (Exception) { }
        }
        public void Dispose() { foreach (var p in sounds.Values) p.Dispose(); foreach (var s in streams) s.Dispose(); }
    }
}
