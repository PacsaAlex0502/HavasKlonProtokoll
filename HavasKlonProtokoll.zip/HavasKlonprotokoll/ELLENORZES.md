# Ellenőrzési jegyzőkönyv

Dátum: 2026. november 3.

## Fordítás

- A teljes Windows Forms alkalmazás sikeresen fordult Mono C# fordítóval, optimalizált WinExe kimenettel, C# 5 nyelvi módban: **0 hiba, 0 figyelmeztetés**.
- A Visual Studio projekt célkeretrendszere **.NET Framework 4.8**. Nincs NuGet-függőség.
- A portré és a szabványos BMP-alapú ICO a fordított EXE-be van ágyazva.
- A csomagban a ténylegesen ellenőrzött EXE szerepel, nem üres helykitöltő.

## Játékmeneti ellenőrzések: 22/22 sikeres

1. Gyors lövedék szakaszalapú találatérzékelése.
2. A cél mellett elhaladó lövedék nem talál.
3. Fix időlépésű mozgás sebessége.
4. Pályaszéllel ütközés.
5. Pillérrel ütközés, pontos középpontból indulva is.
6. Az ellenfél megkerüli az útját blokkoló pillért.
7. A pillér blokkolja a sínpuska lövedékét.
8. Dash: sérthetetlenség és újratöltési idő.
9. Sínpuska sebzése.
10. A kiválasztott fegyver tárából fogy a lőszer.
11. Befejezett újratöltés feltölti a tárat.
12. A fegyverváltás szabályosan megszakítja az újratöltést.
13. Havas-pulzus megöli az osztódó klónt, és két utód keletkezik listamódosítási kivétel nélkül.
14. A pulzus elfogyasztja az energiát és elindítja az effektet.
15. Életfelvétel működése.
16. Hullám vége után három fejlesztés jelenik meg.
17. A felajánlott fejlesztések különböznek.
18. A kiválasztott fejlesztés alkalmazódik és elindul a következő hullám.
19. Az ötödik hullámban megjelenik Havas Prím.
20. A tizenötödik hullám kitisztítása győzelemhez vezet.
21. Halálos kontaktsebzés játék végét okozza.
22. Rögzített véletlenmagú Hardcore szimuláció 35 mp-ig vagy a karakter haláláig kivétel nélkül lefut.

Futtatás Windows alatt: **tests/Tesztek.cmd**. A nyers kimenet: **tests/simulation-results.txt**.

## WinForms integráció: 15/15 sikeres

Valódi Form példánnyal, üzenetfeldolgozással és eseménykezelőkkel:

- Menüvel induló ablak és betöltött beágyazott ikon.
- Enter után ténylegesen haladó játékszimuláció.
- W hatására mozgás, egéresemény hatására lövés.
- R-es újratöltés, 2-es fegyverváltás, Space-es dash.
- Esc hatására a szimuláció ideje megáll; folytatáskor továbbhalad.
- Kódex megnyitása a szünetből és visszatérés.
- Új futam tiszta állapottal, főmenübe visszatérés.
- A rajzolás 960 × 640-es kliensméretben is lefut.

Futtatás Windows alatt: **tests/FeluletTeszt.cmd**. A nyers kimenet: **tests/ui-results.txt**.

## Vizuális ellenőrzés

A játék saját C# renderelőjével készült hét, 1280 × 800 pixeles képernyőkép: főmenü, aréna, főellenfél, szünet, kódex, fejlesztések és eredmény. A képeket átnéztem; a fő szövegek és kezelőszervek nem fedik egymást. Az előnézetek a **Kepernyokepek** mappában vannak.

Az előnézeti jelenetek előre beállított játékállapotokat mutatnak a valódi megjelenítőn. A főellenfélkép, a fejlesztéskép és az eredménykép bemutató állapot; nem egy végigjátszás felvételei.

## Ellenőrzési környezet és gyakorlati korlátok

Linux, Mono 6.8, libgdiplus és virtuális X kijelző. Natív Windows és Visual Studio nem állt rendelkezésre, ezért a Visual Studio-megnyitást, Windowsos hangkimenetet, élő ablakátméretezést, F11-es módváltást és eltérő Windows DPI-beállításokat ott külön érdemes ellenőrizni. A tesztek az alaplogikát és a felület működését igazolják; a 15 hullám nehézségének emberi végigjátszásos kiegyensúlyozását nem helyettesítik.
