using System;
using System.IO;
using System.Xml.Serialization;

namespace HavasKlonprotokoll
{
    public class Profile
    {
        public int BestScore, HardcoreBest, BestWave, TotalKills, Runs, Wins;
        public bool Muted;
        public static string SavePath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HavasKlonprotokoll", "profile.xml"); } }
        public static Profile Load()
        {
            try { if (File.Exists(SavePath)) using (var stream = File.OpenRead(SavePath)) return (Profile)new XmlSerializer(typeof(Profile)).Deserialize(stream); }
            catch (Exception) { /* A damaged/unavailable profile never prevents playing. */ }
            return new Profile();
        }
        public bool Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SavePath));
                string temp = SavePath + ".tmp";
                using (var stream = File.Create(temp)) new XmlSerializer(typeof(Profile)).Serialize(stream, this);
                if (File.Exists(SavePath)) File.Replace(temp, SavePath, null); else File.Move(temp, SavePath);
                return true;
            }
            catch (Exception) { return false; }
        }
    }
}
