using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("HAVAS: Klónprotokoll")]
[assembly: AssemblyDescription("Havas Attila sci-fi aréna akciójátéka – C# Windows Forms")]
[assembly: AssemblyProduct("HAVAS: Klónprotokoll")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("646FF70D-F039-4D21-A360-746DB47257C1")]
