using System;
using System.Collections.Generic;

namespace HavasKlonprotokoll
{
    public struct V2
    {
        public float X, Y;
        public V2(float x, float y) { X = x; Y = y; }
        public float Length { get { return (float)Math.Sqrt(X * X + Y * Y); } }
        public V2 Unit { get { float n = Length; return n > .0001f ? this / n : new V2(1, 0); } }
        public float Angle { get { return (float)Math.Atan2(Y, X); } }
        public static V2 FromAngle(float a) { return new V2((float)Math.Cos(a), (float)Math.Sin(a)); }
        public static V2 operator +(V2 a, V2 b) { return new V2(a.X + b.X, a.Y + b.Y); }
        public static V2 operator -(V2 a, V2 b) { return new V2(a.X - b.X, a.Y - b.Y); }
        public static V2 operator *(V2 a, float b) { return new V2(a.X * b, a.Y * b); }
        public static V2 operator /(V2 a, float b) { return new V2(a.X / b, a.Y / b); }
        public static float Distance(V2 a, V2 b) { return (a - b).Length; }
    }
    public enum ScreenState { Menu, Playing, Upgrade, Paused, GameOver, Victory, Help }
    public enum EnemyKind { Stalker, Runner, Gunner, Tank, Splitter, Prime }
    public enum PickupKind { Health, Ammo, Energy }
    public enum EffectKind { Shot, Hit, Kill, Dash, Nova, Reload, Pickup, Wave, Hurt, Boss, Upgrade }
    public class Enemy
    {
        public int Id;
        public EnemyKind Kind;
        public V2 Pos, Push, DashDirection;
        public float Hp, MaxHp, Radius, Speed, AttackTimer, Flash, Age, Windup, DashTime;
        public int Stage;
        public bool Dead;
        public bool Boss { get { return Kind == EnemyKind.Prime; } }
    }
    public class Bullet
    {
        public V2 Pos, Last, Velocity;
        public float Life, Damage, Radius;
        public bool Hostile, Rail;
        public int Pierce;
        public readonly HashSet<int> Hits = new HashSet<int>();
    }
    public class Particle
    {
        public V2 Pos, Vel;
        public float Life, MaxLife, Size;
        public int Color;
    }
    public class FloatingText
    {
        public V2 Pos;
        public string Text;
        public float Life;
        public int Color;
    }
    public class Pickup
    {
        public V2 Pos;
        public PickupKind Kind;
        public float Age;
    }
    public class Hazard
    {
        public V2 Pos;
        public float Radius, Timer, MaxTimer;
        public bool Fired;
    }
    public class Upgrade
    {
        public string Id, Title, Description, Tag;
        public Upgrade(string id, string title, string description, string tag)
        { Id = id; Title = title; Description = description; Tag = tag; }
    }
    public class Weapon
    {
        public readonly string Name, Sub;
        public readonly int Magazine, Pellets;
        public readonly float Damage, Interval, Reload, Speed, Spread;
        public Weapon(string name, string sub, int mag, int pellets, float damage, float interval, float reload, float speed, float spread)
        { Name = name; Sub = sub; Magazine = mag; Pellets = pellets; Damage = damage; Interval = interval; Reload = reload; Speed = speed; Spread = spread; }
    }
    public class InputFrame
    {
        public V2 Move, Aim;
        public bool Shoot, Dash, Nova, Reload;
    }
}
