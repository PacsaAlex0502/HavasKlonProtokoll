using System;
using System.IO;
using System.Windows.Forms;

namespace HavasKlonprotokoll
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Report(e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (s, e) => Report(e.ExceptionObject as Exception);
            try
            {
                using (var game = new GameForm())
                {
                    if (args.Length == 2 && args[0] == "--render-demo") { game.RenderDemo(args[1]); return; }
                    Application.Run(game);
                }
            }
            catch (Exception e)
            { if (args.Length > 0 && args[0] == "--render-demo") { Console.Error.WriteLine(e); Environment.ExitCode = 1; } else Report(e); }
        }
        private static void Report(Exception e)
        {
            string detail = e == null ? "Ismeretlen hiba" : e.ToString();
            try { File.WriteAllText(Path.Combine(Path.GetTempPath(), "HavasKlonprotokoll-error.log"), detail); } catch { }
            MessageBox.Show("A játék hibát észlelt. Részletek: %TEMP%\\HavasKlonprotokoll-error.log\n\n" + (e == null ? "" : e.Message), "Havas: Klónprotokoll", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
