using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace HavasKlonprotokoll
{
    public partial class GameForm
    {
        private static readonly Color Cyan = Color.FromArgb(72, 235, 220), Red = Color.FromArgb(255, 87, 111), Gold = Color.FromArgb(255, 204, 106);
        private static readonly Color White = Color.FromArgb(232, 240, 248), Muted = Color.FromArgb(130, 151, 171), Panel = Color.FromArgb(13, 23, 36);
        private static readonly Color[] Palette = { Cyan, Red, Color.FromArgb(105, 240, 162), Gold, White, Color.FromArgb(186, 136, 255) };
        private Font F(float size, bool bold = false)
        {
            string key = size + (bold ? "b" : "n"); Font f;
            if (!fonts.TryGetValue(key, out f)) { f = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Pixel); fonts[key] = f; }
            return f;
        }
        private static Color Alpha(Color c, float a) { return Color.FromArgb((int)Math.Max(0, Math.Min(255, a)), c.R, c.G, c.B); }
        private void Txt(Graphics g, string text, float x, float y, float size, Color color, bool bold = false)
        { using (var b = new SolidBrush(color)) g.DrawString(text, F(size, bold), b, x, y, StringFormat.GenericTypographic); }
        private void Center(Graphics g, string text, float x, float y, float width, float size, Color color, bool bold = false)
        { using (var b = new SolidBrush(color)) using (var sf = new StringFormat { Alignment = StringAlignment.Center }) g.DrawString(text, F(size, bold), b, new RectangleF(x, y, width, size * 2.8f), sf); }
        private static void Rect(Graphics g, Color c, float x, float y, float w, float h)
        { if (w <= 0 || h <= 0) return; using (var b = new SolidBrush(c)) g.FillRectangle(b, x, y, w, h); }
        private static void Line(Graphics g, Color c, float x1, float y1, float x2, float y2, float width = 1)
        { using (var p = new Pen(c, width)) g.DrawLine(p, x1, y1, x2, y2); }
        private static GraphicsPath Rounded(RectangleF r, float radius)
        {
            float d = radius * 2; var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90); p.CloseFigure(); return p;
        }
        private static void Box(Graphics g, RectangleF r, Color fill, Color border, float radius = 9)
        { using (var path = Rounded(r, radius)) { using (var b = new SolidBrush(fill)) g.FillPath(b, path); using (var p = new Pen(border)) g.DrawPath(p, path); } }
        private static void Ring(Graphics g, V2 p, float radius, Color c, float width = 2)
        { using (var pen = new Pen(c, width)) g.DrawEllipse(pen, p.X - radius, p.Y - radius, radius * 2, radius * 2); }
        private void Avatar(Graphics g, V2 p, float radius, Color color, bool glow = false)
        {
            if (glow) { Ring(g, p, radius + 5, Alpha(color, 25), 8); Ring(g, p, radius + 2, Alpha(color, 70), 3); }
            g.DrawImage(face, p.X - radius, p.Y - radius, radius * 2, radius * 2);
            Ring(g, p, radius, color, 2);
        }
        private static void ImageOpacity(Graphics g, Image img, Rectangle dest, float opacity)
        {
            using (var attr = new ImageAttributes())
            { var matrix = new ColorMatrix { Matrix33 = opacity }; attr.SetColorMatrix(matrix); g.DrawImage(img, dest, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel, attr); }
        }
        private void BuildAssets()
        {
            face = new Bitmap(160, 160);
            using (var g = Graphics.FromImage(face))
            {
                Configure(g); g.Clear(Color.Transparent); using (var p = new GraphicsPath()) { p.AddEllipse(2, 2, 156, 156); g.SetClip(p); g.DrawImage(portrait, new Rectangle(0, 0, 160, 160), new Rectangle(145, 60, 365, 435), GraphicsUnit.Pixel); }
            }
            arena = new Bitmap(CanvasW, CanvasH);
            using (var g = Graphics.FromImage(arena))
            {
                Configure(g); g.Clear(Color.FromArgb(6, 12, 21));
                using (var grad = new LinearGradientBrush(new Rectangle(0, 120, CanvasW, 600), Color.FromArgb(14, 28, 41), Color.FromArgb(5, 11, 20), 90)) g.FillRectangle(grad, 0, 120, CanvasW, 600);
                for (int x = 40; x <= 1240; x += 40) Line(g, Color.FromArgb(14, 40, 53), x, 140, x, 706);
                for (int y = 146; y <= 706; y += 40) Line(g, Color.FromArgb(14, 40, 53), 42, y, 1238, y);
                for (int x = 140; x < 1200; x += 200) for (int y = 226; y < 700; y += 160)
                { Line(g, Color.FromArgb(33, 61, 74), x - 4, y, x + 4, y); Line(g, Color.FromArgb(33, 61, 74), x, y - 4, x, y + 4); }
                Ring(g, new V2(640, 425), 178, Color.FromArgb(22, 48, 61)); Ring(g, new V2(640, 425), 180, Color.FromArgb(17, 38, 50));
                ImageOpacity(g, face, new Rectangle(520, 305, 240, 240), .055f);
                Center(g, "H A V A S   I N D U S T R I E S", 400, 575, 480, 13, Color.FromArgb(38, 65, 79), true);
                using (var p = new Pen(Color.FromArgb(43, 92, 105), 2)) g.DrawRectangle(p, 40, 138, 1200, 570);
                foreach (V2 p in World.Pillars)
                {
                    using (var b = new SolidBrush(Color.FromArgb(130, 0, 0, 0))) g.FillEllipse(b, p.X - 31, p.Y - 19, 70, 70);
                    using (var b = new SolidBrush(Color.FromArgb(20, 37, 51))) g.FillEllipse(b, p.X - 29, p.Y - 29, 58, 58);
                    Ring(g, p, 29, Color.FromArgb(56, 98, 110), 2); Ring(g, p, 23, Color.FromArgb(32, 69, 82));
                    ImageOpacity(g, face, new Rectangle((int)p.X - 16, (int)p.Y - 16, 32, 32), .42f);
                    Line(g, Cyan, p.X - 10, p.Y + 26, p.X + 10, p.Y + 26, 2);
                }
                // Four portrait terminals make the arena unmistakably Havas themed.
                for (int i = 0; i < 4; i++)
                {
                    float x = i % 2 == 0 ? 62 : 1158, y = i < 2 ? 157 : 633;
                    Box(g, new RectangleF(x, y, 60, 54), Color.FromArgb(14, 29, 40), Color.FromArgb(39, 78, 90), 4);
                    ImageOpacity(g, face, new Rectangle((int)x + 11, (int)y + 4, 38, 38), .32f);
                    Txt(g, "HA / " + (i + 1).ToString("00"), x + 8, y + 41, 9, Muted);
                }
            }
        }
        private bool Hover(RectangleF r) { return r.Contains(mouse.X, mouse.Y); }
        private void Button(Graphics g, string action, string label, RectangleF r, bool primary = false, string hint = "")
        {
            bool hover = Hover(r); hitAreas.Add(new HitArea { Bounds = r, Action = action });
            Color c = primary ? Cyan : White;
            Box(g, r, primary ? Alpha(Cyan, hover ? 46 : 25) : (hover ? Color.FromArgb(31, 45, 59) : Panel), primary ? Alpha(Cyan, hover ? 230 : 150) : Color.FromArgb(51, 70, 87));
            Txt(g, label, r.X + 21, r.Y + (r.Height - 23) / 2 - 1, 18, c, true);
            if (hint.Length > 0) Txt(g, hint, r.Right - 78, r.Y + (r.Height - 16) / 2, 12, primary ? Cyan : Muted);
        }
        private void DrawScene(Graphics g)
        {
            hitAreas.Clear();
            if (state == ScreenState.Menu) DrawMenu(g);
            else if (state == ScreenState.Help) DrawHelp(g);
            else
            {
                DrawGame(g);
                if (state == ScreenState.Upgrade) DrawUpgrade(g);
                if (state == ScreenState.Paused) DrawPause(g);
                if (state == ScreenState.GameOver || state == ScreenState.Victory) DrawResult(g);
            }
            if (state == ScreenState.Playing) DrawCrosshair(g);
        }
        private void DrawMenu(Graphics g)
        {
            g.DrawImageUnscaled(arena, 0, 0); Rect(g, Color.FromArgb(160, 4, 9, 17), 0, 0, 1280, 800);
            g.DrawImage(portrait, new Rectangle(760, 0, 520, 780), new Rectangle(0, 0, 600, 900), GraphicsUnit.Pixel);
            using (var fade = new LinearGradientBrush(new Rectangle(665, 0, 615, 800), Color.FromArgb(255, 5, 11, 20), Color.FromArgb(50, 5, 11, 20), 0f)) g.FillRectangle(fade, 665, 0, 615, 800);
            using (var fade = new LinearGradientBrush(new Rectangle(760, 500, 520, 300), Color.FromArgb(0, 5, 11, 20), Color.FromArgb(255, 5, 11, 20), 90)) g.FillRectangle(fade, 760, 500, 520, 300);
            Line(g, Alpha(Cyan, 100), 765, 96, 765, 672, 2);
            Rect(g, Cyan, 66, 67, 29, 3); Txt(g, "HAVAS INDUSTRIES  /  BIZTONSÁGI INCIDENS 001", 108, 57, 12, Cyan, true);
            Txt(g, "HAVAS", 61, 113, 104, White, true);
            Txt(g, "K L Ó N P R O T O K O L L", 71, 235, 25, Cyan, true);
            Txt(g, "Egyetlen eredeti. Végtelen másolat.", 72, 296, 24, White);
            Txt(g, "Havas Attilaként állítsd le a klónhadsereget.\n15 hullám. 3 fegyver. Egy esély az eredetiségre.", 74, 340, 17, Muted);
            DifficultyCard(g, false, new RectangleF(74, 414, 263, 72)); DifficultyCard(g, true, new RectangleF(351, 414, 263, 72));
            Button(g, "start", "PROTOKOLL INDÍTÁSA", new RectangleF(74, 508, 540, 64), true, "ENTER  →");
            Button(g, "help", "IRÁNYÍTÁS ÉS KÓDEX", new RectangleF(74, 587, 340, 51), false, "H");
            Button(g, "exit", "KILÉPÉS", new RectangleF(429, 587, 185, 51));
            Avatar(g, new V2(837, 655), 32, Cyan, true);
            Txt(g, "01 // AZ EREDETI", 887, 628, 13, Cyan, true); Txt(g, "HAVAS ATTILA", 883, 650, 28, White, true);
            Txt(g, "MINDEN KLÓN EGYETLEN FORRÁSBÓL.", 887, 689, 11, Muted);
            Line(g, Color.FromArgb(35, 59, 73), 74, 689, 613, 689);
            Txt(g, "REKORD / " + (hardcore ? profile.HardcoreBest : profile.BestScore).ToString("N0"), 74, 708, 14, Gold, true);
            Txt(g, "ÖSSZES KLÓN / " + profile.TotalKills.ToString("N0"), 330, 708, 13, Muted);
            Footer(g);
        }
        private void DifficultyCard(Graphics g, bool hard, RectangleF r)
        {
            bool selected = hard == hardcore; Color c = hard ? Red : Cyan;
            hitAreas.Add(new HitArea { Bounds = r, Action = hard ? "hardcore" : "normal" });
            Box(g, r, selected ? Alpha(c, 20) : Panel, selected ? c : Color.FromArgb(41, 58, 75));
            Txt(g, hard ? "HARDCORE" : "OPERÁTOR", r.X + 18, r.Y + 12, 17, selected ? c : White, true);
            Txt(g, hard ? "Gyorsabb klónok. +40% sebzés." : "Kemény harc. Több regeneráció.", r.X + 18, r.Y + 40, 12, Muted);
            if (selected) Rect(g, c, r.Right - 19, r.Y + 17, 6, 6);
        }
        private void Footer(Graphics g)
        {
            Rect(g, Color.FromArgb(7, 13, 22), 0, 762, 1280, 38);
            Txt(g, "HAVAS: KLÓNPROTOKOLL  /  1.0", 32, 775, 10, Muted, true);
            Txt(g, "F11  TELJES KÉPERNYŐ     M  HANG: " + (profile.Muted ? "KI" : "BE"), 854, 773, 11, Muted);
        }
        private void DrawGame(Graphics g)
        {
            g.DrawImageUnscaled(arena, 0, 0); if (world == null) return;
            var saved = g.Save(); g.SetClip(new Rectangle(41, 139, 1198, 568));
            if (world.Shake > 0 && state == ScreenState.Playing) g.TranslateTransform((float)Math.Sin(uiTime * 90) * world.Shake * .5f, (float)Math.Cos(uiTime * 103) * world.Shake * .4f);
            foreach (Hazard h in world.Hazards)
            {
                float progress = Math.Max(0, 1 - h.Timer / h.MaxTimer);
                using (var b = new SolidBrush(Alpha(Red, h.Fired ? 100 * (1 + h.Timer / .35f) : 18 + progress * 30))) g.FillEllipse(b, h.Pos.X - h.Radius, h.Pos.Y - h.Radius, h.Radius * 2, h.Radius * 2);
                Ring(g, h.Pos, h.Radius, Alpha(Red, 220), 2); Ring(g, h.Pos, Math.Max(1, h.Radius * progress), Alpha(Red, 160), 2);
                Line(g, Red, h.Pos.X - 10, h.Pos.Y, h.Pos.X + 10, h.Pos.Y, 2); Line(g, Red, h.Pos.X, h.Pos.Y - 10, h.Pos.X, h.Pos.Y + 10, 2);
            }
            foreach (Pickup p in world.Pickups)
            {
                Color c = p.Kind == PickupKind.Health ? Palette[2] : p.Kind == PickupKind.Ammo ? Gold : Cyan;
                float bob = (float)Math.Sin(uiTime * 4 + p.Pos.X) * 3;
                Ring(g, new V2(p.Pos.X, p.Pos.Y + bob), 12, Alpha(c, 70), 5);
                Box(g, new RectangleF(p.Pos.X - 10, p.Pos.Y - 10 + bob, 20, 20), Panel, c, 5);
                Center(g, p.Kind == PickupKind.Health ? "+" : p.Kind == PickupKind.Ammo ? "III" : "Q", p.Pos.X - 10, p.Pos.Y - 11 + bob, 20, 15, c, true);
            }
            foreach (Bullet b in world.Bullets)
            {
                Color c = b.Hostile ? Red : b.Rail ? Cyan : Gold;
                V2 trail = b.Pos - b.Velocity.Unit * (b.Rail ? 72 : b.Hostile ? 15 : 25);
                Line(g, Alpha(c, 25), trail.X, trail.Y, b.Pos.X, b.Pos.Y, b.Hostile ? 13 : b.Rail ? 11 : 7);
                Line(g, c, trail.X, trail.Y, b.Pos.X, b.Pos.Y, b.Hostile ? 4 : b.Rail ? 3 : 2);
                Ring(g, b.Pos, b.Hostile ? 3 : 1.5f, White, 2);
            }
            foreach (Enemy e in world.Enemies) if (!e.Dead) DrawEnemy(g, e);
            DrawPlayer(g);
            foreach (Particle p in world.Particles)
            {
                float a = p.Life / p.MaxLife; Color c = Alpha(Palette[p.Color], 220 * a);
                Rect(g, c, p.Pos.X - p.Size / 2, p.Pos.Y - p.Size / 2, p.Size, p.Size);
            }
            if (world.NovaFlash > 0)
            { float r = (1 - world.NovaFlash) * (320 + world.Level("nova") * 35); Ring(g, world.Player, Math.Max(1, r), Alpha(Cyan, world.NovaFlash * 230), 5); Ring(g, world.Player, Math.Max(1, r - 14), Alpha(White, world.NovaFlash * 80), 2); }
            foreach (FloatingText t in world.Texts) Center(g, t.Text, t.Pos.X - 85, t.Pos.Y, 170, 15, Alpha(Palette[t.Color], Math.Min(255, t.Life * 450)), true);
            g.Restore(saved);
            if (world.HurtFlash > 0) Rect(g, Alpha(Red, world.HurtFlash * 65), 41, 139, 1198, 568);
            DrawHud(g);
            if (world.BannerTimer > 0 && state == ScreenState.Playing)
            {
                float a = Math.Min(1, world.BannerTimer * 2);
                Box(g, new RectangleF(317, 166, 646, 85), Color.FromArgb((int)(a * 235), 8, 17, 28), Alpha(world.BossEncounter ? Red : Cyan, a * 100));
                Center(g, world.Banner, 320, 175, 640, 27, Alpha(world.BossEncounter ? Red : Cyan, a * 255), true);
                Center(g, world.SubBanner, 320, 215, 640, 11, Alpha(Muted, a * 255));
            }
            if (world.Combo >= 3)
            {
                Txt(g, world.Combo.ToString("00") + "  KOMBO", 1049, 167, 23, Gold, true);
                Txt(g, "SZORZÓ  ×" + Math.Min(5, 1 + world.Combo / 8), 1060, 201, 12, Muted);
                Bar(g, 1053, 225, 150, 3, world.ComboTime / 3.5f, Gold);
            }
        }
        private void DrawEnemy(Graphics g, Enemy e)
        {
            Color c = Palette[World.EnemyColor(e.Kind)]; float r = e.Radius;
            float spawn = Math.Min(1, e.Age / .4f); if (spawn < 1) r *= .5f + spawn * .5f;
            using (var b = new SolidBrush(Color.FromArgb(110, 0, 0, 0))) g.FillEllipse(b, e.Pos.X - r, e.Pos.Y - r + 7, r * 2, r * 2);
            Avatar(g, e.Pos, r, e.Flash > .1f ? White : c, e.Boss);
            if (e.Age < .7f) Ring(g, e.Pos, r + 10 + (float)Math.Sin(uiTime * 15) * 4, Alpha(c, 130), 2);
            if (e.Boss)
            {
                Ring(g, e.Pos, r + 9, Alpha(Red, 130), 2);
                for (int i = 0; i < 6; i++) { V2 d = V2.FromAngle(uiTime * .4f + i * 1.0472f); Line(g, c, e.Pos.X + d.X * (r + 9), e.Pos.Y + d.Y * (r + 9), e.Pos.X + d.X * (r + 17), e.Pos.Y + d.Y * (r + 17), 3); }
                Center(g, "HAVAS PRÍM", e.Pos.X - 80, e.Pos.Y - r - 30, 160, 14, Red, true);
                if (e.Windup > 0)
                {
                    V2 dir = (world.Player - e.Pos).Unit; Line(g, Alpha(Red, 170), e.Pos.X, e.Pos.Y, e.Pos.X + dir.X * 700, e.Pos.Y + dir.Y * 700, 3);
                    Center(g, "ROHAM!", e.Pos.X - 70, e.Pos.Y + r + 10, 140, 13, Red, true);
                }
            }
            else
            {
                if (e.Hp < e.MaxHp) Bar(g, e.Pos.X - r, e.Pos.Y - r - 9, r * 2, 3, e.Hp / e.MaxHp, c);
                string name = e.Kind == EnemyKind.Runner ? "ROHAM" : e.Kind == EnemyKind.Gunner ? "LÖVÉSZ" : e.Kind == EnemyKind.Tank ? "TITÁN" : e.Kind == EnemyKind.Splitter ? "OSZTÓDÓ" : "KLÓN";
                Center(g, name, e.Pos.X - 60, e.Pos.Y + r + 4, 120, 8, Alpha(c, 180), true);
            }
        }
        private void DrawPlayer(Graphics g)
        {
            V2 p = world.Player; float a = (world.Aim - p).Angle;
            bool blink = world.Invulnerable > 0 && ((int)(uiTime * 24) % 2 == 0);
            Ring(g, p, 27 + (float)Math.Sin(uiTime * 3), Alpha(Cyan, blink ? 230 : 80), 2);
            if (world.DashTime > 0) Ring(g, p, 34, White, 3);
            V2 dir = V2.FromAngle(a), side = new V2(-dir.Y, dir.X);
            V2 gun = p + dir * 22 + side * 9;
            Line(g, Color.FromArgb(33, 63, 74), gun.X, gun.Y, gun.X + dir.X * 24, gun.Y + dir.Y * 24, world.WeaponIndex == 1 ? 10 : 7);
            Line(g, Cyan, gun.X + dir.X * 7, gun.Y + dir.Y * 7, gun.X + dir.X * 25, gun.Y + dir.Y * 25, 2);
            Avatar(g, p, 21, blink ? White : Cyan, true);
            Center(g, "EREDETI", p.X - 50, p.Y + 32, 100, 9, Cyan, true);
            if (world.ReloadTimer > 0)
            {
                using (var pen = new Pen(Gold, 3)) g.DrawArc(pen, p.X - 32, p.Y - 32, 64, 64, -90, world.ReloadProgress * 360);
                Center(g, "ÚJRATÖLTÉS", p.X - 65, p.Y - 56, 130, 10, Gold, true);
            }
        }
        private static void Bar(Graphics g, float x, float y, float width, float height, float fraction, Color color)
        { Rect(g, Color.FromArgb(28, 43, 55), x, y, width, height); Rect(g, color, x, y, width * Math.Max(0, Math.Min(1, fraction)), height); }
        private void DrawHud(Graphics g)
        {
            Rect(g, Color.FromArgb(8, 15, 25), 0, 0, 1280, 126); Line(g, Color.FromArgb(39, 68, 82), 0, 125, 1280, 125);
            Avatar(g, new V2(59, 58), 32, Cyan);
            Txt(g, "HAVAS ATTILA", 111, 21, 21, White, true); Txt(g, "AZ EREDETI  /  OPERÁTOR 01", 112, 49, 10, Muted, true);
            Bar(g, 113, 76, 228, 8, world.Hp / world.MaxHp, world.Hp < world.MaxHp * .3f ? Red : Cyan);
            Txt(g, ((int)Math.Ceiling(world.Hp)) + " / " + (int)world.MaxHp + " ÉLET", 113, 93, 11, Muted);
            Line(g, Color.FromArgb(33, 54, 69), 380, 26, 380, 100);
            Stat(g, "PONTSZÁM", world.Score.ToString("N0"), 415, Gold);
            Stat(g, "HULLÁM", world.Wave.ToString("00") + " / 15", 615, White);
            Stat(g, "KLÓNOK", (world.Enemies.Count + world.SpawnRemaining).ToString("00"), 799, Red);
            Stat(g, "IDŐ", TimeString(world.Time), 948, White);
            Txt(g, hardcore ? "HARDCORE" : "OPERÁTOR", 1110, 28, 13, hardcore ? Red : Cyan, true);
            Txt(g, "ESC  SZÜNET", 1110, 58, 11, Muted); Txt(g, "M  HANG " + (profile.Muted ? "KI" : "BE"), 1110, 82, 10, Muted);
            Enemy boss = world.Enemies.Find(e => e.Boss && !e.Dead);
            if (boss != null)
            {
                Rect(g, Color.FromArgb(9, 15, 23), 371, 116, 538, 39);
                Center(g, "HAVAS PRÍM  //  " + (boss.Hp < boss.MaxHp * .45f ? "TÚLHAJTÁS" : "KLÓNVEZÉR"), 380, 119, 520, 10, Red, true);
                Bar(g, 384, 141, 512, 5, boss.Hp / boss.MaxHp, Red);
            }
            Rect(g, Color.FromArgb(8, 15, 25), 0, 722, 1280, 78); Line(g, Color.FromArgb(39, 68, 82), 0, 722, 1280, 722);
            for (int i = 0; i < 3; i++)
            {
                float x = 27 + i * 230; bool active = i == world.WeaponIndex; Color c = active ? Cyan : Muted;
                Box(g, new RectangleF(x, 735, 216, 53), active ? Color.FromArgb(17, 39, 47) : Panel, active ? Alpha(Cyan, 150) : Color.FromArgb(31, 47, 62), 5);
                Txt(g, (i + 1).ToString(), x + 12, 747, 21, c, true);
                Txt(g, i == 0 ? "KARABÉLY" : i == 1 ? "SÖRÉTES" : "SÍNPUSKA", x + 39, 743, 11, c, true);
                Txt(g, world.Ammo[i] + " / " + world.Magazine(i), x + 39, 761, 14, active && world.Ammo[i] == 0 ? Red : White, true);
                if (active && world.ReloadTimer > 0) Bar(g, x + 2, 784, 212, 3, world.ReloadProgress, Gold);
            }
            bool charged = world.Charge >= 100;
            Box(g, new RectangleF(735, 735, 248, 53), charged ? Alpha(Cyan, 24) : Panel, charged ? Cyan : Color.FromArgb(31, 47, 62), 5);
            Txt(g, "Q", 748, 747, 22, charged ? Cyan : Muted, true);
            Txt(g, "HAVAS-PULZUS", 786, 743, 11, charged ? Cyan : White, true);
            Txt(g, charged ? "KÉSZ — AKTIVÁLD!" : ((int)world.Charge) + "% / TERÜLETSEBZÉS", 786, 761, 11, charged ? Cyan : Muted);
            Bar(g, 737, 785, 244, 2, world.Charge / 100, Cyan);
            Box(g, new RectangleF(998, 735, 254, 53), Panel, Color.FromArgb(31, 47, 62), 5);
            Txt(g, "SPACE", 1010, 752, 12, world.DashCooldown <= 0 ? Cyan : Muted, true);
            Txt(g, "DASH / " + (world.DashCooldown <= 0 ? "KÉSZ" : world.DashCooldown.ToString("0.0") + " mp"), 1076, 743, 12, White, true);
            Txt(g, "R  ÚJRATÖLTÉS", 1076, 765, 10, Muted);
            Bar(g, 1000, 785, 250, 2, 1 - world.DashCooldown / world.DashMax, Cyan);
        }
        private void Stat(Graphics g, string label, string value, float x, Color color)
        { Txt(g, label, x, 28, 11, Muted, true); Txt(g, value, x - 2, 50, 29, color, true); }
        private static string TimeString(float seconds) { return ((int)seconds / 60).ToString("00") + ":" + ((int)seconds % 60).ToString("00"); }
        private void DrawCrosshair(Graphics g)
        {
            if (mouse.X < 42 || mouse.X > 1238 || mouse.Y < 140 || mouse.Y > 706) return;
            Color c = world != null && world.ReloadTimer > 0 ? Gold : Cyan;
            Ring(g, mouse, 7, Alpha(c, 200), 1);
            Line(g, c, mouse.X - 15, mouse.Y, mouse.X - 10, mouse.Y, 2); Line(g, c, mouse.X + 10, mouse.Y, mouse.X + 15, mouse.Y, 2);
            Line(g, c, mouse.X, mouse.Y - 15, mouse.X, mouse.Y - 10, 2); Line(g, c, mouse.X, mouse.Y + 10, mouse.X, mouse.Y + 15, 2);
            Rect(g, White, mouse.X - 1, mouse.Y - 1, 2, 2);
        }
        private void Overlay(Graphics g) { Rect(g, Color.FromArgb(220, 3, 8, 15), 0, 0, 1280, 800); }
        private void DrawUpgrade(Graphics g)
        {
            Overlay(g); Avatar(g, new V2(640, 116), 35, Cyan, true);
            Center(g, "HULLÁM TELJESÍTVE", 0, 174, 1280, 14, Cyan, true);
            Center(g, "FEJLESZD AZ EREDETIT", 0, 203, 1280, 38, White, true);
            Center(g, "Válassz egy modult. A következő hullám a választás után indul.", 0, 261, 1280, 16, Muted);
            for (int i = 0; i < world.Choices.Count; i++)
            {
                Upgrade u = world.Choices[i]; var r = new RectangleF(91 + i * 374, 327, 350, 304); bool hover = Hover(r);
                hitAreas.Add(new HitArea { Bounds = r, Action = "upgrade" + i });
                Box(g, r, hover ? Color.FromArgb(20, 43, 53) : Panel, hover ? Cyan : Color.FromArgb(52, 77, 92), 12);
                Txt(g, "0" + (i + 1) + " / " + u.Tag, r.X + 26, r.Y + 24, 12, Cyan, true);
                Avatar(g, new V2(r.X + 49, r.Y + 95), 24, i == 0 ? Cyan : i == 1 ? Gold : Palette[5]);
                Txt(g, "SZINT " + (world.Level(u.Id) + 1), r.X + 89, r.Y + 88, 13, Muted, true);
                Txt(g, u.Title, r.X + 24, r.Y + 144, 21, White, true);
                Txt(g, u.Description, r.X + 25, r.Y + 188, 14, Muted);
                Line(g, Color.FromArgb(40, 62, 76), r.X + 25, r.Y + 248, r.Right - 25, r.Y + 248);
                Txt(g, "[" + (i + 1) + "]  MODUL TELEPÍTÉSE  →", r.X + 26, r.Y + 267, 12, hover ? Cyan : White, true);
            }
            Center(g, "ÉLETERŐ HELYREÁLLÍTVA RÉSZBEN  /  TÁRAK FELTÖLTVE", 0, 676, 1280, 12, Muted);
        }
        private void DrawPause(Graphics g)
        {
            Overlay(g); Box(g, new RectangleF(365, 171, 550, 475), Panel, Color.FromArgb(43, 81, 94), 14);
            Avatar(g, new V2(640, 231), 32, Cyan, true); Center(g, "PROTOKOLL SZÜNETEL", 365, 285, 550, 29, White, true);
            Center(g, "Havas Attila megvár. A klónok is.", 365, 333, 550, 15, Muted);
            Button(g, "resume", "FOLYTATÁS", new RectangleF(410, 385, 460, 55), true, "ESC");
            Button(g, "help", "IRÁNYÍTÁS", new RectangleF(410, 455, 460, 49));
            Button(g, "restart", "ÚJ FUTAM", new RectangleF(410, 519, 220, 49));
            Button(g, "menu", "FŐMENÜ", new RectangleF(650, 519, 220, 49));
            Center(g, "Az aktuális futam az újrakezdéssel vagy kilépéssel véget ér.", 365, 601, 550, 11, Muted);
        }
        private void DrawResult(Graphics g)
        {
            Overlay(g); bool win = state == ScreenState.Victory; Color c = win ? Cyan : Red;
            Box(g, new RectangleF(260, 95, 760, 609), Panel, Alpha(c, 130), 14);
            Avatar(g, new V2(640, 166), 43, c, true);
            Center(g, win ? "AZ EREDETI GYŐZÖTT." : "PROTOKOLL MEGSZAKÍTVA", 260, 233, 760, 34, win ? White : Red, true);
            Center(g, win ? "15 hullám. A klónhálózat leállt. Havas Attila maradt." : "A másolatok most erősebbek voltak. Indíts új futamot.", 260, 286, 760, 16, Muted);
            Center(g, world.Score.ToString("N0"), 260, 331, 760, 70, Gold, true);
            Center(g, newRecord ? "ÚJ REKORD / PONTSZÁM" : "PONTSZÁM", 260, 417, 760, 12, newRecord ? Cyan : Muted, true);
            ResultStat(g, "HULLÁM", world.Wave + " / 15", 335); ResultStat(g, "KLÓNOK", world.Kills.ToString(), 510);
            ResultStat(g, "LEGJOBB KOMBO", world.BestCombo.ToString(), 685); ResultStat(g, "IDŐ", TimeString(world.Time), 860);
            Button(g, "restart", "ÚJRAINDÍTÁS", new RectangleF(329, 565, 350, 57), true, "ENTER");
            Button(g, "menu", "FŐMENÜ", new RectangleF(699, 565, 250, 57));
            Center(g, saveFailed ? "A rekord mentése nem sikerült; ebben a munkamenetben megmarad." : "A rekordokat a játék automatikusan elmenti ezen a számítógépen.", 280, 656, 720, 11, saveFailed ? Gold : Muted);
        }
        private void ResultStat(Graphics g, string name, string value, float x)
        { Center(g, name, x - 65, 476, 130, 10, Muted, true); Center(g, value, x - 65, 497, 130, 24, White, true); }
        private void DrawHelp(Graphics g)
        {
            g.Clear(Color.FromArgb(6, 12, 21));
            Avatar(g, new V2(76, 65), 28, Cyan); Txt(g, "OPERÁTORI KÓDEX", 126, 39, 31, White, true);
            Txt(g, "HAVAS ATTILA / A KLÓNPROTOKOLL LEÁLLÍTÁSA", 129, 81, 11, Cyan, true);
            Line(g, Color.FromArgb(35, 61, 76), 48, 126, 1232, 126);
            Txt(g, "IRÁNYÍTÁS", 60, 154, 16, Cyan, true);
            string[,] controls = { { "W A S D / NYILAK", "Mozgás" }, { "EGÉR / BAL GOMB", "Célzás / folyamatos lövés" }, { "1 / 2 / 3 / GÖRGŐ", "Karabély / sörétes / sínpuska" }, { "R", "Újratöltés (korlátlan tartalék)" }, { "SPACE / JOBB GOMB", "Dash: rövid sérthetetlenség" }, { "Q", "Havas-pulzus 100 energiánál" }, { "ESC / F11 / M", "Szünet / teljes képernyő / hang" } };
            for (int i = 0; i < controls.GetLength(0); i++)
            { float y = 203 + i * 50; Box(g, new RectangleF(60, y, 210, 33), Panel, Color.FromArgb(38, 60, 76), 4); Txt(g, controls[i, 0], 74, y + 8, 12, White, true); Txt(g, controls[i, 1], 285, y + 7, 15, Muted); }
            Txt(g, "ISMERD A MÁSOLATOKAT", 680, 154, 16, Red, true);
            string[] names = { "KLÓN", "ROHAM", "LÖVÉSZ", "TITÁN", "OSZTÓDÓ", "HAVAS PRÍM" };
            string[] desc = { "Közel kerül és támad. Tarts távolságot.", "Gyors, kevés élettel. Ne szorulj sarokba.", "Távolról lő. A pillér fedezéket ad.", "Lassú és páncélozott. Sínpuskával üsd át.", "Két gyors klónra esik szét.", "Főellenfél az 5., 10. és 15. hullámban." };
            for (int i = 0; i < 6; i++)
            {
                float y = 210 + i * 63; Color c = i == 2 ? Palette[5] : i == 3 ? Gold : i == 4 ? Palette[2] : Red;
                Avatar(g, new V2(704, y + 12), 20, c); Txt(g, names[i], 741, y - 6, 13, c, true); Txt(g, desc[i], 741, y + 16, 13, Muted);
            }
            Box(g, new RectangleF(60, 593, 537, 90), Panel, Color.FromArgb(39, 74, 87));
            Txt(g, "15 HULLÁM. MINDEN VÁLASZTÁS SZÁMÍT.", 79, 609, 14, Gold, true);
            Txt(g, "Hullámonként egy végleges fejlesztést választhatsz.\nA piros jelzésekből dash-sel térj ki. Q törli a közeli lövedékeket.", 79, 638, 13, Muted);
            Button(g, "back", "VISSZA", new RectangleF(945, 665, 255, 52), true, "ESC");
            Txt(g, "Fiktív sci-fi klóntörténet a megadott portré felhasználásával.", 680, 626, 12, Muted);
            Footer(g);
        }
    }
}
