# HAVAS: KLÓNPROTOKOLL

**Havas Attila az eredeti. Mindenki más csak másolat.**

Teljes C# Windows Forms aréna-akciójáték a megadott portréval. A képeket és a programikonját az EXE tartalmazza. Nincs NuGet-csomag, játékmotor, internetkapcsolat vagy külön letöltendő grafikai elem.

## Indítás Visual Studióban

1. Csomagold ki **az egész ZIP-et** egy mappába.
2. Nyisd meg a **HavasKlonprotokoll.sln** fájlt Visual Studióban.
3. Szükséges összetevők: **.NET asztali fejlesztés** és **.NET Framework 4.8 célzócsomag / fejlesztői csomag**. Ezeket a Visual Studio Installerben tudod hozzáadni. A projekt Windows Forms / .NET Framework projekt.
4. A Solution Explorerben a HavasKlonprotokoll projekten jobb gomb → **Set as Startup Project**, ha szükséges.
5. Nyomj **F5**-öt vagy **Ctrl+F5**-öt.

Windows 10/11 és Visual Studio 2022 vagy újabb használható a megfelelő .NET Framework összetevőkkel. A projekt AnyCPU; nem szükséges x64-re átállítani. A Form és a teljes felület C#-ból épül fel, nincs külön Form1.Designer.cs.

## Azonnali indítás fordítás nélkül

A **bin/Release/HavasKlonprotokoll.exe** a lefordított játék. Windows alatt indítsd dupla kattintással; a mellette lévő **HavasKlonprotokoll.exe.config** maradjon vele. .NET Framework 4.8 futtatókörnyezet szükséges. A forráskódot is teljes egészében megkapod, saját módosításhoz nyisd meg a solutiont.

Alternatíva: **Forditas.cmd** a Windows beépített .NET Framework C# fordítójával készít új EXE-t, Visual Studio nélkül. A normál fejlesztési út a solution és az F5.

## A játék

Egy fiktív sci-fi klónlaborban Havas Attila másolatai önállósodtak. Az eredeti operátorként 15 hullámon keresztül kell leállítanod a hálózatot. A történet és a Havas Industries elnevezés kitalált játékelem.

- **3 azonnal elérhető fegyver:** automata karabély, hétszemes sörétes, több ellenfélen átütő sínpuska.
- **5 klóntípus:** alapklón, gyors rohamklón, távolsági lövész, nagy életű titán, kétfelé osztódó klón.
- **Havas Prím főellenfél:** az 5., 10. és 15. hullámban. Körkörös lövedékek, előre jelzett robbanászónák, második fázis és rohamtámadás.
- **13 fejlesztés:** hullámok között három véletlen modul közül választhatsz. A bónuszok az adott futam végéig maradnak meg.
- **Dash és Havas-pulzus:** a dash rövid sérthetetlenséget ad; a pulzus területet sebez és eltünteti a közeli ellenséges lövedékeket.
- **Operátor és Hardcore mód**, kombóval növekvő pontszorzó, élet-, lőszer- és energiafelvétel.
- Részecskék, becsapódási effektek, képernyőrázás, szintetizált hangeffektek, teljes képernyő, automatikus szünet ablakváltáskor.
- **A portré a menüben, a főhősön, minden klónon, a főellenfélen, a fejlesztési kártyákon, a HUD-on és az aréna termináljain is megjelenik.**

## Irányítás

| Gomb | Művelet |
|---|---|
| WASD vagy nyilak | Mozgás |
| Egér | Célzás |
| Bal egérgomb nyomva | Folyamatos lövés |
| 1 / 2 / 3 vagy egérgörgő | Fegyverváltás |
| R | Újratöltés |
| Space / Shift / jobb egérgomb | Dash |
| Q | Havas-pulzus 100 energiánál |
| 1 / 2 / 3 a fejlesztésképernyőn | Fejlesztés választása |
| Esc | Szünet / folytatás; a főmenüben kilépés |
| F11 | Teljes képernyő váltása |
| M | Hang ki/be |
| Enter a főmenüben / eredménynél | Indítás / új futam |

## Taktika

A tartalék lőszer korlátlan, de a tárak végesek. Fegyverváltáskor az éppen futó újratöltés megszakad. A pillérek blokkolják a mozgást és mindkét fél lövedékeit. A dash sem visz át a pilléreken. A piros körök a főellenfél hamarosan becsapódó támadásait jelölik: térj ki belőlük. A villogó, megjelenő ellenfelek rövid türelmi időt adnak.

Hullám végén a megmaradt felvehető tárgyak automatikusan begyűlnek, a tárak feltöltődnek és kapsz némi életet. A pulzushoz szükséges energia klónok kiiktatásával és energiafelvétellel töltődik. A 15. hullám összes ellenfelének legyőzése győzelmet ad. Halálkor új futamot kell indítani.

## Mentés

A rekordok és a hangbeállítás automatikusan ide kerülnek:

`%LOCALAPPDATA%\HavasKlonprotokoll\profile.xml`

A két nehézségi szintnek külön pontrekordja van. Futam közbeni állapotmentés nincs; az újrakezdés, főmenübe lépés és bezárás megszakítja az aktuális futamot. Sérült vagy nem írható profil esetén a játék továbbra is elindul. A mentési mappa törlésével a rekordok nullázhatók.

## A forrás felépítése

| Fájl | Tartalom |
|---|---|
| Program.cs | Belépési pont és hibajelzés |
| GameForm.cs | Windows Forms ablak, vezérlés, 120 Hz-es szimulációs ciklus, képernyőállapotok |
| Simulation.cs | Mozgás, fegyverek, ellenfelek, főellenfél, ütközések, hullámok és fejlesztések |
| Rendering.cs | Teljes saját rajzolású GDI+ felület, HUD és effektek |
| Model.cs | Vektorok és játékelemek adattípusai |
| Audio.cs | Külső hangfájlok nélküli PCM hangeffektek |
| Profile.cs | Helyi XML-profil mentése |
| Assets | Beágyazott portré és ikon |
| tests | Játékmeneti ellenőrzések és Windows tesztindító |
| Kepernyokepek | A valódi C# renderelővel készített előnézetek |

A beállítások a World osztály elején módosíthatók; a fegyverparaméterek a `Weapons` tömbben, a hullámok száma a `LastWave` állandóban található.

## Ellenőrzés és korlátok

A teljes forrást lefordítottam, a játékmeneti teszteket futtattam, és a valódi WinForms rajzolóval képeket készítettem a fő képernyőkről. A részletes ellenőrzési lista az **ELLENORZES.md** fájlban van. Az ellenőrzés Linux/Mono környezetben történt, natív Windows/Visual Studio futtatás itt nem volt elérhető. Windowsos hangkimenet és DPI-kezelés ezért külön kézi ellenőrzést igényelhet.

A játék egy komplett, egyarénás 2D projekt; a felülete GDI+-szal készül. A hangmotor rövid hangeffekteket játszik le, nem többsávos zenemotor. Külső eszközt vagy 3D motort nem használ.
