@echo off
setlocal
cd /d "%~dp0.."
set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" (
  echo Nem talalhato a C# fordito.
  pause
  exit /b 1
)
"%HAVAS_CSC%" /nologo /langversion:5 /out:"%TEMP%\HavasSimulationTests.exe" Model.cs Simulation.cs tests\SimulationTests.cs
if errorlevel 1 exit /b 1
"%TEMP%\HavasSimulationTests.exe"
set "HAVAS_RESULT=%ERRORLEVEL%"
pause
exit /b %HAVAS_RESULT%
