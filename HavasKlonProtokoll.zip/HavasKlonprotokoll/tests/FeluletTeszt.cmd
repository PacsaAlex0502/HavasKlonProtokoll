@echo off
setlocal
cd /d "%~dp0.."
set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" set "HAVAS_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%HAVAS_CSC%" (
  echo Nem talalhato a C# fordito.
  pause
  exit /b 1
)
if not exist bin\Release\HavasKlonprotokoll.exe (
  echo Elobb forditsd le a jatekot Release modban vagy a Forditas.cmd fajllal.
  pause
  exit /b 1
)
"%HAVAS_CSC%" /nologo /langversion:5 /out:bin\Release\HavasUiSmokeTests.exe /reference:bin\Release\HavasKlonprotokoll.exe /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Core.dll tests\UiSmokeTests.cs
if errorlevel 1 exit /b 1
bin\Release\HavasUiSmokeTests.exe
set "HAVAS_RESULT=%ERRORLEVEL%"
pause
exit /b %HAVAS_RESULT%
