using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using HavasKlonprotokoll;

internal static class UiSmokeTests
{
    private static int checks;
    private static readonly BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance;
    private static object Get(GameForm f, string name) { return typeof(GameForm).GetField(name, Flags).GetValue(f); }
    private static void Call(GameForm f, string name, params object[] values) { typeof(GameForm).GetMethod(name, Flags).Invoke(f, values); }
    private static void Check(bool ok, string name) { if (!ok) throw new Exception("FAIL: " + name); checks++; Console.WriteLine("PASS: " + name); }
    private static void Press(GameForm f, Keys k)
    { Call(f, "OnGameKeyDown", f, new KeyEventArgs(k)); ((HashSet<Keys>)Get(f, "keys")).Remove(k); }
    private static void Pump(int ms)
    { var watch = Stopwatch.StartNew(); while (watch.ElapsedMilliseconds < ms) { Application.DoEvents(); Thread.Sleep(2); } }
    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        using (var f = new GameForm())
        {
            ((AudioEngine)Get(f, "audio")).Muted = true; f.Show(); Pump(80);
            Check((ScreenState)Get(f, "state") == ScreenState.Menu, "Form opens on menu");
            Check(f.Icon != null && f.Icon.Width > 0, "embedded icon loads");
            Press(f, Keys.Enter); Pump(70); var w = (World)Get(f, "world");
            Check((ScreenState)Get(f, "state") == ScreenState.Playing && w.Time > 0, "Enter starts live game loop");
            float y = w.Player.Y; Call(f, "OnGameKeyDown", f, new KeyEventArgs(Keys.W)); Pump(120);
            ((HashSet<Keys>)Get(f, "keys")).Remove(Keys.W);
            Check(w.Player.Y < y - 10, "W moves player through keyboard handler");
            Call(f, "OnGameMouseDown", f, new MouseEventArgs(MouseButtons.Left, 1, 950, 440, 0)); Pump(100);
            typeof(GameForm).GetField("mouseDown", Flags).SetValue(f, false);
            Check(w.ShotsFired > 0 && w.Ammo[0] < 30, "mouse handler fires weapon");
            Press(f, Keys.R); Pump(25); Check(w.ReloadTimer > 0, "R starts reload through UI");
            Press(f, Keys.D2); Check(w.WeaponIndex == 1 && w.ReloadTimer == 0, "2 switches weapon and cancels reload");
            Press(f, Keys.Space); Pump(25); Check(w.DashCooldown > 0, "Space activates dash");
            Press(f, Keys.Escape); float pausedTime = w.Time; Pump(90);
            Check((ScreenState)Get(f, "state") == ScreenState.Paused && w.Time == pausedTime, "Escape pauses simulation");
            Call(f, "Act", "help"); Check((ScreenState)Get(f, "state") == ScreenState.Help, "help opens from pause");
            Call(f, "Act", "back"); Check((ScreenState)Get(f, "state") == ScreenState.Paused, "help returns to pause");
            Press(f, Keys.Escape); Pump(60); Check(w.Time > pausedTime, "Escape resumes simulation");
            Call(f, "Act", "restart"); var next = (World)Get(f, "world");
            Check(next != w && next.Wave == 1 && next.Score == 0, "restart creates clean run");
            Call(f, "Act", "menu"); Check((World)Get(f, "world") == null && (ScreenState)Get(f, "state") == ScreenState.Menu, "menu discards current run");
            f.Close();
        }
        using (var small = new GameForm())
        {
            small.ClientSize = new Size(960, 640);
            using (var b = new Bitmap(960, 640)) using (var g = Graphics.FromImage(b))
                Call(small, "OnPaint", new PaintEventArgs(g, new Rectangle(0, 0, 960, 640)));
            Check(small.ClientSize.Width == 960, "scaled paint at 960 x 640 succeeds");
        }
        Console.WriteLine("ALL " + checks + " UI CHECKS PASSED");
    }
}
