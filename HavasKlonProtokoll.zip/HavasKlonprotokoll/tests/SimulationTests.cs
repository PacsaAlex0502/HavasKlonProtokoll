using System;
using HavasKlonprotokoll;

internal static class SimulationTests
{
    private static int checks;
    private static void Check(bool value, string name) { if (!value) throw new Exception("FAIL: " + name); checks++; Console.WriteLine("PASS: " + name); }
    private static void Step(World w, float seconds, InputFrame input = null)
    { for (int i = 0; i < (int)(seconds * 120); i++) w.Update(1f / 120, input ?? new InputFrame { Aim = new V2(1100, 440) }); }
    private static World Empty() { var w = new World(false, 123); w.Enemies.Clear(); w.SpawnRemaining = 0; return w; }
    public static void Main()
    {
        Check(World.SegmentHit(new V2(0, 0), new V2(1000, 0), new V2(500, 0), 5), "fast projectile swept collision");
        Check(!World.SegmentHit(new V2(0, 0), new V2(1000, 0), new V2(500, 20), 5), "swept collision rejects miss");
        var w = new World(false, 123); Step(w, .5f, new InputFrame { Move = new V2(1, 0), Aim = new V2(1200, 440) });
        Check(w.Player.X > 755 && w.Player.X < 765, "fixed step movement speed");
        V2 p = World.Resolve(new V2(-100, -100), 20); Check(p.X >= World.Left + 20 && p.Y >= World.Top + 20, "arena bounds");
        p = World.Resolve(World.Pillars[0], 20); Check(V2.Distance(p, World.Pillars[0]) >= 48.99f, "pillar collision including exact centre");
        w = Empty(); w.Player = new V2(380, 420); var steered = w.Spawn(EnemyKind.Stalker, new V2(380, 240)); steered.Age = 2; Step(w, 3.5f);
        Check(steered.Pos.Y > 350, "enemy steers around a pillar instead of getting stuck");
        w = Empty(); w.Player = new V2(380, 240); var covered = w.Spawn(EnemyKind.Tank, new V2(380, 450)); covered.Age = 2; w.SwitchWeapon(2); Step(w, .15f);
        w.Update(1f / 120, new InputFrame { Aim = covered.Pos, Shoot = true }); Step(w, .2f);
        Check(covered.Hp == covered.MaxHp, "pillar blocks rail projectile before target");
        w = new World(false, 1); w.Update(1f / 120, new InputFrame { Dash = true, Move = new V2(1, 0), Aim = new V2(1000, 400) });
        Check(w.Invulnerable > 0 && w.DashCooldown > 1, "dash grants invulnerability and cooldown");
        w = Empty(); var e = w.Spawn(EnemyKind.Tank, new V2(800, 440)); e.Age = 2; w.SwitchWeapon(2);
        Step(w, .2f); w.Update(1f / 120, new InputFrame { Aim = e.Pos, Shoot = true }); Step(w, .2f);
        Check(e.Hp < e.MaxHp, "rail weapon damages target"); Check(w.Ammo[2] == 4, "shooting consumes selected magazine");
        w.Ammo[2] = 0; w.BeginReload(); Step(w, 2.1f); Check(w.Ammo[2] == w.Magazine(2) && w.ReloadTimer == 0, "reload finishes with full magazine");
        w.Ammo[0] = 1; w.SwitchWeapon(0); w.BeginReload(); w.SwitchWeapon(1); Check(w.ReloadTimer == 0 && w.Ammo[0] == 1, "weapon switch cancels reload safely");
        w = Empty(); e = w.Spawn(EnemyKind.Splitter, new V2(700, 440)); e.Hp = 1; e.Age = 2; w.Charge = 100;
        w.Update(1f / 120, new InputFrame { Nova = true, Aim = e.Pos });
        Check(w.Kills == 1 && w.Enemies.Count == 2, "nova kills splitter and creates two children without mutation error");
        Check(w.Charge < 10 && w.NovaFlash > 0, "nova consumes charge and starts effect");
        w = Empty(); w.Hp = 50; w.Pickups.Add(new Pickup { Pos = w.Player, Kind = PickupKind.Health }); Step(w, .05f);
        Check(w.Hp == 70 && w.Pickups.Count == 0, "health pickup collection");
        w = Empty(); Step(w, 1.5f); Check(w.AwaitingUpgrade && w.Choices.Count == 3, "cleared wave offers three upgrades");
        Check(w.Choices[0].Id != w.Choices[1].Id && w.Choices[1].Id != w.Choices[2].Id, "upgrade choices are distinct");
        string id = w.Choices[0].Id; w.ChooseUpgrade(0); Check(w.Wave == 2 && !w.AwaitingUpgrade && w.Level(id) == 1, "upgrade applies and starts next wave");
        w = Empty(); w.Wave = 4; w.StartWave(); Check(w.Wave == 5 && w.Enemies.Exists(x => x.Boss), "fifth wave spawns Havas Prime");
        w = Empty(); w.Wave = 15; Step(w, 1.5f); Check(w.Won && !w.AwaitingUpgrade, "fifteenth clear reaches victory");
        w = Empty(); e = w.Spawn(EnemyKind.Stalker, w.Player); e.Age = 2; w.Hp = 1; Step(w, .01f); Check(w.Dead && w.Hp == 0, "lethal enemy contact reaches game over");
        w = new World(true, 765); Step(w, 35, new InputFrame { Aim = new V2(950, 440), Shoot = true, Move = new V2(.2f, .1f) });
        Check(w.Dead || w.Time > 30, "long seeded hardcore simulation completes safely");
        Console.WriteLine("ALL " + checks + " CHECKS PASSED");
    }
}
