using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace HavasKlonprotokoll
{
    public partial class GameForm : Form
    {
        private const int CanvasW = 1280, CanvasH = 800;
        private readonly Timer timer = new Timer();
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private readonly HashSet<Keys> keys = new HashSet<Keys>();
        private readonly List<HitArea> hitAreas = new List<HitArea>();
        private readonly Dictionary<string, Font> fonts = new Dictionary<string, Font>();
        private readonly Profile profile;
        private readonly AudioEngine audio;
        private World world;
        private ScreenState state = ScreenState.Menu;
        private ScreenState helpReturn = ScreenState.Menu;
        private Image portrait;
        private Bitmap face, arena;
        private V2 mouse = new V2(640, 400);
        private bool mouseDown, dashPressed, novaPressed, reloadPressed, hardcore, fullscreen, resultSaved, newRecord, saveFailed;
        private float uiTime, accumulator;
        private double lastTick;
        private Rectangle restoreBounds;
        private FormWindowState restoreState;
        private bool silentDemo;
        private sealed class HitArea { public RectangleF Bounds; public string Action; }

        public GameForm()
        {
            Text = "HAVAS: Klónprotokoll | Havas Attila";
            ClientSize = new Size(CanvasW, CanvasH); MinimumSize = new Size(960, 640);
            StartPosition = FormStartPosition.CenterScreen; BackColor = Color.FromArgb(6, 10, 17);
            AutoScaleMode = AutoScaleMode.None; KeyPreview = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HavasKlonprotokoll.Assets.havas-attila.jpg"))
            { if (stream == null) throw new FileNotFoundException("Hiányzó beágyazott Havas Attila portré."); using (Image img = Image.FromStream(stream)) portrait = new Bitmap(img); }
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("HavasKlonprotokoll.Assets.havas.ico"))
            { if (stream != null) { try { Icon = new Icon(stream); } catch (ArgumentException) { /* The optional window icon must never block startup. */ } } }
            BuildAssets(); profile = Profile.Load(); audio = new AudioEngine { Muted = profile.Muted };
            timer.Interval = 16; timer.Tick += Tick; lastTick = clock.Elapsed.TotalSeconds; timer.Start();
            KeyDown += OnGameKeyDown; KeyUp += (s, e) => keys.Remove(e.KeyCode);
            MouseMove += (s, e) => mouse = ToCanvas(e.Location);
            MouseDown += OnGameMouseDown; MouseUp += (s, e) => { if (e.Button == MouseButtons.Left) mouseDown = false; };
            MouseWheel += (s, e) => { if (state == ScreenState.Playing) world.SwitchWeapon((world.WeaponIndex + (e.Delta > 0 ? 2 : 1)) % 3); };
            MouseLeave += (s, e) => mouseDown = false;
            Deactivate += (s, e) => { keys.Clear(); ClearInput(); if (state == ScreenState.Playing) state = ScreenState.Paused; };
        }
        private V2 ToCanvas(Point p)
        {
            float scale = Math.Min(ClientSize.Width / (float)CanvasW, ClientSize.Height / (float)CanvasH);
            if (scale <= 0) return new V2(0, 0);
            return new V2((p.X - (ClientSize.Width - CanvasW * scale) / 2) / scale, (p.Y - (ClientSize.Height - CanvasH * scale) / 2) / scale);
        }
        private void ClearInput() { mouseDown = dashPressed = novaPressed = reloadPressed = false; }
        private void StartGame()
        {
            world = new World(hardcore); world.Sound = k => { if (!silentDemo) audio.Play(k); };
            state = ScreenState.Playing; resultSaved = false; newRecord = false; saveFailed = false;
            keys.Clear(); ClearInput(); accumulator = 0; audio.Play(EffectKind.Wave);
        }
        private void Tick(object sender, EventArgs args)
        {
            double now = clock.Elapsed.TotalSeconds; float elapsed = (float)Math.Min(.08, now - lastTick); lastTick = now;
            uiTime += elapsed;
            if (state == ScreenState.Playing && world != null)
            {
                accumulator += elapsed;
                while (accumulator >= 1f / 120 && state == ScreenState.Playing)
                {
                    V2 move = new V2((Down(Keys.D) || Down(Keys.Right) ? 1 : 0) - (Down(Keys.A) || Down(Keys.Left) ? 1 : 0),
                        (Down(Keys.S) || Down(Keys.Down) ? 1 : 0) - (Down(Keys.W) || Down(Keys.Up) ? 1 : 0));
                    if (move.Length > 1) move = move.Unit;
                    world.Update(1f / 120, new InputFrame { Move = move, Aim = mouse, Shoot = mouseDown, Dash = dashPressed, Nova = novaPressed, Reload = reloadPressed });
                    dashPressed = novaPressed = reloadPressed = false; accumulator -= 1f / 120;
                    if (world.Dead || world.Won) { state = world.Won ? ScreenState.Victory : ScreenState.GameOver; SaveResult(); ClearInput(); }
                    else if (world.AwaitingUpgrade) { state = ScreenState.Upgrade; ClearInput(); }
                }
            }
            else accumulator = 0;
            Invalidate();
        }
        private bool Down(Keys key) { return keys.Contains(key); }
        protected override bool IsInputKey(Keys keyData)
        {
            Keys k = keyData & Keys.KeyCode;
            return k == Keys.Up || k == Keys.Down || k == Keys.Left || k == Keys.Right || base.IsInputKey(keyData);
        }
        private void SaveResult()
        {
            if (resultSaved || world == null) return; resultSaved = true;
            int previous = hardcore ? profile.HardcoreBest : profile.BestScore; newRecord = world.Score > previous;
            if (hardcore) profile.HardcoreBest = Math.Max(profile.HardcoreBest, world.Score); else profile.BestScore = Math.Max(profile.BestScore, world.Score);
            profile.BestWave = Math.Max(profile.BestWave, world.Wave); profile.TotalKills += world.Kills; profile.Runs++; if (world.Won) profile.Wins++;
            saveFailed = !profile.Save();
        }
        private void OnGameKeyDown(object sender, KeyEventArgs e)
        {
            bool first = keys.Add(e.KeyCode); e.Handled = true; e.SuppressKeyPress = true; if (!first) return;
            if (e.KeyCode == Keys.F11) { ToggleFullscreen(); return; }
            if (e.KeyCode == Keys.M) { profile.Muted = !profile.Muted; audio.Muted = profile.Muted; profile.Save(); return; }
            if (e.KeyCode == Keys.Escape)
            {
                if (state == ScreenState.Playing) { state = ScreenState.Paused; ClearInput(); }
                else if (state == ScreenState.Paused) { state = ScreenState.Playing; ClearInput(); }
                else if (state == ScreenState.Help) state = helpReturn;
                else if (state == ScreenState.Menu) Close();
                return;
            }
            if (state == ScreenState.Playing)
            {
                if (e.KeyCode == Keys.Space || e.KeyCode == Keys.ShiftKey) dashPressed = true;
                if (e.KeyCode == Keys.Q) novaPressed = true;
                if (e.KeyCode == Keys.R) reloadPressed = true;
                if (e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D3) world.SwitchWeapon((int)e.KeyCode - (int)Keys.D1);
                if (e.KeyCode >= Keys.NumPad1 && e.KeyCode <= Keys.NumPad3) world.SwitchWeapon((int)e.KeyCode - (int)Keys.NumPad1);
            }
            else if (state == ScreenState.Menu)
            {
                if (e.KeyCode == Keys.Enter) StartGame();
                if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right) hardcore = !hardcore;
                if (e.KeyCode == Keys.H || e.KeyCode == Keys.F1) { helpReturn = state; state = ScreenState.Help; }
            }
            else if (state == ScreenState.Upgrade && e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D3) Choose((int)e.KeyCode - (int)Keys.D1);
            else if (state == ScreenState.Paused && e.KeyCode == Keys.Enter) state = ScreenState.Playing;
            else if ((state == ScreenState.GameOver || state == ScreenState.Victory) && e.KeyCode == Keys.Enter) StartGame();
        }
        private void OnGameMouseDown(object sender, MouseEventArgs e)
        {
            mouse = ToCanvas(e.Location);
            if (state == ScreenState.Playing) { if (e.Button == MouseButtons.Left) mouseDown = true; if (e.Button == MouseButtons.Right) dashPressed = true; return; }
            if (e.Button != MouseButtons.Left) return;
            for (int i = hitAreas.Count - 1; i >= 0; i--) if (hitAreas[i].Bounds.Contains(mouse.X, mouse.Y)) { Act(hitAreas[i].Action); break; }
        }
        private void Choose(int i)
        { if (state != ScreenState.Upgrade || i >= world.Choices.Count) return; world.ChooseUpgrade(i); state = ScreenState.Playing; keys.Clear(); ClearInput(); audio.Play(EffectKind.Upgrade); }
        private void Act(string action)
        {
            if (action == "start" || action == "restart") StartGame();
            else if (action == "normal") hardcore = false;
            else if (action == "hardcore") hardcore = true;
            else if (action == "resume") { state = ScreenState.Playing; ClearInput(); }
            else if (action == "menu") { world = null; state = ScreenState.Menu; keys.Clear(); ClearInput(); }
            else if (action == "help") { helpReturn = state; state = ScreenState.Help; }
            else if (action == "back") state = helpReturn;
            else if (action == "exit") Close();
            else if (action.StartsWith("upgrade")) Choose(int.Parse(action.Substring(7)));
        }
        private void ToggleFullscreen()
        {
            if (!fullscreen)
            { restoreBounds = Bounds; restoreState = WindowState; WindowState = FormWindowState.Normal; FormBorderStyle = FormBorderStyle.None; Bounds = Screen.FromControl(this).Bounds; fullscreen = true; }
            else { FormBorderStyle = FormBorderStyle.Sizable; Bounds = restoreBounds; WindowState = restoreState; fullscreen = false; }
        }
        public void RenderDemo(string directory)
        {
            silentDemo = true; audio.Muted = true; timer.Stop(); Directory.CreateDirectory(directory);
            uiTime = 3; RenderToFile(Path.Combine(directory, "01-menu.png"));
            StartGame(); world.Sound = null; world.Wave = 7; world.Score = 18450; world.Kills = 146; world.Charge = 100; world.Hp = 97;
            world.BannerTimer = 0; world.Combo = 12; world.ComboTime = 2;
            world.Enemies.Clear(); world.Player = new V2(630, 445); world.Aim = new V2(880, 430);
            world.Spawn(EnemyKind.Stalker, new V2(812, 440)); world.Spawn(EnemyKind.Runner, new V2(700, 580));
            world.Spawn(EnemyKind.Gunner, new V2(1050, 300)); world.Spawn(EnemyKind.Tank, new V2(480, 275));
            world.Spawn(EnemyKind.Splitter, new V2(230, 455)); world.Spawn(EnemyKind.Stalker, new V2(1000, 595));
            foreach (Enemy e in world.Enemies) e.Age = 2;
            world.Bullets.Add(new Bullet { Pos = new V2(750, 437), Velocity = new V2(950, -30), Life = 1, Radius = 3 });
            world.Bullets.Add(new Bullet { Pos = new V2(875, 345), Velocity = new V2(-230, 60), Life = 1, Radius = 6, Hostile = true });
            world.Pickups.Add(new Pickup { Pos = new V2(550, 550), Kind = PickupKind.Health });
            mouse = new V2(830, 437); RenderToFile(Path.Combine(directory, "02-jatek.png"));
            world.Wave = 10; world.Enemies.Clear(); var boss = world.Spawn(EnemyKind.Prime, new V2(720, 275)); boss.Age = 3; boss.Hp *= .4f;
            world.Hazards.Add(new Hazard { Pos = new V2(680, 470), Radius = 80, Timer = .4f, MaxTimer = 1.05f });
            RenderToFile(Path.Combine(directory, "03-foboss.png"));
            state = ScreenState.Paused; RenderToFile(Path.Combine(directory, "04-szunet.png"));
            state = ScreenState.Help; RenderToFile(Path.Combine(directory, "05-iranyitas.png"));
            world.Enemies.Clear(); world.SpawnRemaining = 0;
            world.Update(1.3f, new InputFrame { Aim = mouse }); state = ScreenState.Upgrade;
            RenderToFile(Path.Combine(directory, "06-fejlesztes.png"));
            state = ScreenState.GameOver; RenderToFile(Path.Combine(directory, "07-eredmeny.png"));
        }
        private void RenderToFile(string path)
        { using (var bitmap = new Bitmap(CanvasW, CanvasH)) { using (var g = Graphics.FromImage(bitmap)) { Configure(g); DrawScene(g); } bitmap.Save(path, ImageFormat.Png); } }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); Graphics g = e.Graphics; g.Clear(Color.FromArgb(4, 7, 12));
            float scale = Math.Min(ClientSize.Width / (float)CanvasW, ClientSize.Height / (float)CanvasH); if (scale <= 0) return;
            g.TranslateTransform((ClientSize.Width - CanvasW * scale) / 2, (ClientSize.Height - CanvasH * scale) / 2); g.ScaleTransform(scale, scale);
            Configure(g); DrawScene(g);
        }
        private static void Configure(Graphics g)
        { g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBilinear; g.PixelOffsetMode = PixelOffsetMode.HighQuality; g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit; }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            { timer.Stop(); timer.Dispose(); if (audio != null) audio.Dispose(); if (portrait != null) portrait.Dispose(); if (face != null) face.Dispose(); if (arena != null) arena.Dispose(); foreach (Font f in fonts.Values) f.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
